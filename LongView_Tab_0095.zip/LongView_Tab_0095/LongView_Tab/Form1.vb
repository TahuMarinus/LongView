Imports System
Imports System.Data.OleDb
Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private DataProvider As String = " Provider=Microsoft.Jet.OLEDB.4.0;"
    Private DataSource As String = " Data Source=" & Directory.GetCurrentDirectory() & "\..\" & "dta\LongView.mdb;"
    Private DataUserName As String = " User Id=admin;"
    Private DataPassWord As String = " Password=;"
    Private ConnString As String = DataProvider & DataSource & DataUserName & DataPassWord

    Private dtadap As OleDbDataAdapter
    Private dtatbl As DataTable = New DataTable
    Private dtarow As DataRow

    'Queries
    Private QRY As String = ""

    ' Student
    Public StudentIndex As Integer = -1
    Private StudentNamePublic As String = "StudentNamePublic"
    Private StudentUserName As String = "StudentUserName"
    Private StudentPassWord As String = "StudentPassWord"
    Private StudentDecisionInitial As Integer = 0

    Private EnrollmentStepIndex = 0
    'Private StudentWhenCreated As Date
    'Private StudentWhenUpdated As Date
    'Private StudentNamePrefix As String = "StudentNamePrefix"
    'Private StudentNamePersonal As String = "StudentNamePersonal"
    'Private StudentNameInitials As String = "StudentNameInitials"
    'Private StudentNameFamilial As String = "StudentNameFamilial"
    'Private StudentNameSuffix As String = "StudentNameSuffix"

    Private StudentDegree As String = ""

    Private StudentDecisionCount As Integer = 0

    'Dim tmpStr As String
    'Dim tmpStrAry As Array

    Dim dtacon As New OleDbConnection(connString)
    Dim dtacmd As OleDbCommand = Nothing
    Dim dtardr As OleDbDataReader = Nothing

    'Dim tabOld = 0
    'Dim tabNew = 0

    Dim SUB_name As String

    Dim QRY_Student_Find As String = "SELECT StudentIndex FROM Students WHERE 0 = 0 AND StudentUserName = '{StudentUserName}' AND StudentPassWord = '{StudentPassWord}'"
    Dim QRY_StudentSelect_Load As String = "SELECT StudentUserName, StudentPassWord FROM Students WHERE StudentIndex = {StudentIndex}"
    Dim QRY_StudentSelect_Save As String = "INSERT INTO Students (StudentUserName, StudentPassWord) VALUES ('{StudentUserName}', '{StudentPassWord}')"

    Dim QRY_StudentDetail_Load As String = "SELECT StudentNamePrefix, StudentNamePersonal, StudentNameInitials, StudentNameFamilial, StudentNameSuffix, StudentNamePublic FROM Students WHERE StudentIndex = {StudentIndex}"
    Dim QRY_StudentDetail_Save As String = "UPDATE Students SET StudentUserName = '{StudentUserName}' , StudentPassWord = '{StudentPassWord}' WHERE StudentIndex = {StudentIndex}"

    Dim QRY_StudentDegreeItem_Load As String = "SELECT MajorIndex, MajorTitle FROM StudentsDegree, MajorDefinitions WHERE 0 = 0 AND StudentIndex = {StudentIndex} AND StudentsDegree.DegreeIndex = MajorDefinitions.MajorIndex"
    Dim QRY_StudentDegreeList_Load As String = "SELECT MajorIndex, MajorTitle FROM MajorDefinitions"
    Dim QRY_StudentDegree_Save As String = "INSERT INTO StudentsDegree (StudentIndex, DegreeIndex, DegreeType) SELECT {StudentIndex} AS StudentIndex, {DegreeIndex} As DegreeIndex, 0 As DegreeType FROM StudentsDegree WHERE StudentIndex = {StudentIndex} AND DegreeIndex NOT IN({DegreeIndex}) "

    Dim QRY_CourseRequiredList_Load As String = "SELECT CourseIndex, CourseName FROM Courses WHERE 0 = 0 AND CourseIndex IN ( SELECT CourseIndex FROM StudentsDegree, MajorRequirements WHERE StudentIndex = {StudentIndex} )"
    ''Dim QRY_CourseRequiredItem_Load As String = "SELECT Courses.CourseIndex, Courses.CourseTitle FROM CourseRequisites, Courses WHERE 0 = 0 AND CourseRequisites.CourseDonePast = Courses.CourseIndex AND CourseTodoNext = 2"
    Dim QRY_CourseRequiredRequiredItem_Load As String = "SELECT CourseDonePast FROM CourseRequisites WHERE 0=0 AND MajorIndex = {MajorIndex} AND CourseTodoNext = {CourseIndex}"

    Dim QRY_CoursePossibleListRequisitedMet_Load As String = "SELECT CoursesTodoNext.CourseIndex AS CourseIndex, CoursesTodoNext.CourseName AS CourseName, EnrollmentStepDonePast.TermDone, EnrollmentStepTodoNext.TermDone FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext, Courses CoursesTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND EnrollmentStepTodoNext.CourseIndex = CoursesTodoNext.CourseIndex AND EnrollmentStepDonePast.TermDone <> '0000.0' AND EnrollmentStepTodoNext.TermDone = '0000.0' AND EnrollmentStepDonePast.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex}"
    Dim QRY_CoursePossibleListEarnedGradeTooLow_Load As String = "SELECT EnrollmentStepTodoNext.CourseIndex FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex} AND EnrollmentStepDonePast.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepDonePast.EnrollmentStepIndex = EnrollmentStepTodoNext.EnrollmentStepIndex AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND CourseRequisites.CourseGradeMinimum > EnrollmentStepDonePast.GradePointsEarned"
    Dim QRY_CoursePossibleListEarnedHoursTooLow_Load As String = "SELECT EnrollmentStepTodoNext.CourseI FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex} AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND CourseRequisites.CourseHoursMinimum > {AccumulatedHours}"

    Dim QRY_CoursePossibleItem_Load As String = "SELECT Courses.CourseIndex AS CourseIndex, Courses.CourseTitle AS CourseTitle, EnrollmentStep.TermDone AS TermDone FROM EnrollmentStep, Courses WHERE 0 = 0 AND EnrollmentStep.CourseIndex = Courses.CourseIndex AND EnrollmentStep.StudentIndex = {StudentIndex} AND EnrollmentStep.CourseIndex = {CourseIndex}"
    Dim QRY_CourseCompleteList_Load As String = "SELECT Courses.CourseIndex AS CourseIndex, Courses.CourseName AS CourseName FROM EnrollmentStep, Courses WHERE 0 = 0 AND StudentIndex = {StudentIndex} AND TermDone <> '0000.0'"
    Dim QRY_CourseCompleteItem_Load As String = "SELECT CourseName, CourseTitle FROM EnrollmentStep, Courses WHERE 0 = 0 AND StudentIndex = {StudentIndex} AND EnrollmentStep.CourseIndex = Courses.CourseIndex AND EnrollmentStep.CourseIndex = {CourseIndex}"

    Dim QRY_EnrollmentStepAbove_Load As String = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepDonePast as EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepTodoNext = {EnrollmentStepIndex} )"
    Dim QRY_EnrollmentStepTween_Load As String = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepIndex = {EnrollmentStepIndex} )"
    Dim QRY_EnrollmentStepBelow_Load As String = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepTodoNext as EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepDonePast = {EnrollmentStepIndex} )"

    Dim ANS_Student_Find As DataTable

    Dim ANS_StudentSelect_Load As DataTable
    Dim ANS_StudentSelect_Save As DataTable

    Dim ANS_StudentDetail_Load As DataTable
    Dim ANS_StudentDetail_Save As DataTable

    Dim ANS_StudentDegreeItem_Load As DataTable
    Dim ANS_StudentDegreeItem_Save As DataTable
    Dim ANS_StudentDegreeList_Load As DataTable
    Dim ANS_StudentDegree_Save As DataTable

    Dim ANS_CourseRequiredList_Load As DataTable
    Dim ANS_CourseRequiredItem_Load As DataTable
    Dim ANS_CourseRequiredRequiredItem_Load As DataTable
    Dim ANS_CoursePossibleListRequisitedMet_Load As DataTable
    Dim ANS_CoursePossibleListEarnedGradeTooLow_Load As DataTable
    Dim ANS_CoursePossibleListEarnedHoursTooLow_Load As DataTable
    Dim ANS_CoursePossibleItem_Load As DataTable
    Dim ANS_CourseCompleteList_Load As DataTable
    Dim ANS_CourseCompleteItem_Load As DataTable

    Dim ANS_EnrollmentStepAbove_Load As DataTable
    Dim ANS_EnrollmentStepTween_Load As DataTable
    Dim ANS_EnrollmentStepBelow_Load As DataTable

    'Dim VAL_Student_Find
    'Dim VAR_StudentSelect_Load
    'Dim VAL_StudentDetail_Load As DataTable
    'Dim VAL_StudentDegree_Load As DataTable
    'Dim VAL_CourseRequiredList_Load As DataTable
    'Dim VAL_CourseRequiredItem_Load As DataTable
    'Dim VAL_CourseRequiredRequiredItem_Load As DataTable
    'Dim VAL_CoursePossibleListRequisitedMet_Load As DataTable
    'Dim VAL_CoursePossibleListEarnedGradeTooLow_Load As DataTable
    'Dim VAL_CoursePossibleListEarnedHoursTooLow_Load As DataTable
    'Dim VAL_CoursePossibleItem_Load As DataTable
    'Dim VAL_CourseCompleteList_Load As DataTable
    'Dim VAL_CourseCompleteItem_Load As DataTable

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TXT_done_selected_termyear As System.Windows.Forms.TextBox
    Friend WithEvents LST_status As System.Windows.Forms.ListBox
    Friend WithEvents LST_Decision As System.Windows.Forms.ListView
    Friend WithEvents BTN_About_Update As System.Windows.Forms.Button
    Friend WithEvents TAB_Courses As System.Windows.Forms.TabControl
    Friend WithEvents TAB_Student As System.Windows.Forms.TabControl
    Friend WithEvents TAB_StudentSelect As System.Windows.Forms.TabPage
    Friend WithEvents TAB_StudentDetail As System.Windows.Forms.TabPage
    Friend WithEvents TAB_StudentDegree As System.Windows.Forms.TabPage
    Friend WithEvents BTN_DecisionHead As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionRise As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionTail As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionFall As System.Windows.Forms.Button
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TAB_CoursesRequired As System.Windows.Forms.TabPage
    Friend WithEvents TAB_CoursesPossible As System.Windows.Forms.TabPage
    Friend WithEvents TAB_CoursesComplete As System.Windows.Forms.TabPage
    Friend WithEvents LBL_CoursesRequiredRequisites As System.Windows.Forms.Label
    Friend WithEvents LST_CoursesRequiredList As System.Windows.Forms.ListBox
    Friend WithEvents LBL_CoursesRequiredName As System.Windows.Forms.Label
    Friend WithEvents TXT_CoursesRequiredName As System.Windows.Forms.TextBox
    Friend WithEvents LST_CoursesPossibleList As System.Windows.Forms.ListBox
    Friend WithEvents TXT_CoursesPossibleTermPart As System.Windows.Forms.TextBox
    Friend WithEvents TXT_CoursesPossibleTermYear As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CoursesPossibleTermYear As System.Windows.Forms.Label
    Friend WithEvents TXT_CoursesPossibleName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CoursesPossibleName As System.Windows.Forms.Label
    Friend WithEvents BTN_CoursesPossible_Save As System.Windows.Forms.Button
    Friend WithEvents LST_CoursesCompleteList As System.Windows.Forms.ListBox
    Friend WithEvents TXT_CourseCompleteTermPart As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CourseCompleteName As System.Windows.Forms.Label
    Friend WithEvents TXT_CourseCompleteName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CourseCompleteTermYear As System.Windows.Forms.Label
    Friend WithEvents LST_CoursesRequiredRequisites As System.Windows.Forms.ListBox
    Friend WithEvents LBL_CoursesPossibleTermPart As System.Windows.Forms.Label
    Friend WithEvents LBL_CourseCompleteTermPart As System.Windows.Forms.Label
    Friend WithEvents LBL_CoursesRequiredList As System.Windows.Forms.Label
    Friend WithEvents LBL_CoursesPossibleList As System.Windows.Forms.Label
    Friend WithEvents LBL_CoursesCompleteList As System.Windows.Forms.Label
    Friend WithEvents TAB_Enrollment As System.Windows.Forms.TabControl
    Friend WithEvents LST_Enrollment As System.Windows.Forms.TabPage
    Friend WithEvents TXT_StudentSelect_StudentPassWord As System.Windows.Forms.TextBox
    Friend WithEvents TXT_StudentSelect_StudentUserName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_StudentSelect_StudentPassWord As System.Windows.Forms.Label
    Friend WithEvents LBL_StudentSelect_StudentUserName As System.Windows.Forms.Label
    Friend WithEvents BTN_StudentSelect_SignOn As System.Windows.Forms.Button
    Friend WithEvents BTN_StudentSelect_SignUp As System.Windows.Forms.Button
    Friend WithEvents TXT_StudentDetail_StudentPassWord As System.Windows.Forms.TextBox
    Friend WithEvents LBL_StudentDetail_StudentPassWord As System.Windows.Forms.Label
    Friend WithEvents LBL_StudentDetail_StudentUserName As System.Windows.Forms.Label
    Friend WithEvents BTN_StudentDetail_SignOut As System.Windows.Forms.Button
    Friend WithEvents BTN_StudentDetail_Save As System.Windows.Forms.Button
    Friend WithEvents TXT_StudentDetail_StudentUserName As System.Windows.Forms.TextBox
    Friend WithEvents LST_StudentDegree As System.Windows.Forms.ListBox
    Friend WithEvents BTN_StudentDegree_Save As System.Windows.Forms.Button
    Friend WithEvents CMB_StudentDegreeList As System.Windows.Forms.ComboBox
    Friend WithEvents LBL_StudentDegree As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.LBL_CoursesRequiredRequisites = New System.Windows.Forms.Label
        Me.LST_CoursesRequiredList = New System.Windows.Forms.ListBox
        Me.LBL_CoursesRequiredName = New System.Windows.Forms.Label
        Me.TXT_CoursesRequiredName = New System.Windows.Forms.TextBox
        Me.LST_CoursesPossibleList = New System.Windows.Forms.ListBox
        Me.TXT_CoursesPossibleTermPart = New System.Windows.Forms.TextBox
        Me.TXT_CoursesPossibleTermYear = New System.Windows.Forms.TextBox
        Me.LBL_CoursesPossibleTermYear = New System.Windows.Forms.Label
        Me.TXT_CoursesPossibleName = New System.Windows.Forms.TextBox
        Me.LBL_CoursesPossibleName = New System.Windows.Forms.Label
        Me.BTN_CoursesPossible_Save = New System.Windows.Forms.Button
        Me.LST_CoursesCompleteList = New System.Windows.Forms.ListBox
        Me.TXT_CourseCompleteTermPart = New System.Windows.Forms.TextBox
        Me.TXT_done_selected_termyear = New System.Windows.Forms.TextBox
        Me.LBL_CourseCompleteName = New System.Windows.Forms.Label
        Me.TXT_CourseCompleteName = New System.Windows.Forms.TextBox
        Me.LBL_CourseCompleteTermYear = New System.Windows.Forms.Label
        Me.LST_CoursesRequiredRequisites = New System.Windows.Forms.ListBox
        Me.LBL_CoursesPossibleTermPart = New System.Windows.Forms.Label
        Me.LBL_CourseCompleteTermPart = New System.Windows.Forms.Label
        Me.TAB_Courses = New System.Windows.Forms.TabControl
        Me.TAB_CoursesRequired = New System.Windows.Forms.TabPage
        Me.LBL_CoursesRequiredList = New System.Windows.Forms.Label
        Me.TAB_CoursesPossible = New System.Windows.Forms.TabPage
        Me.LBL_CoursesPossibleList = New System.Windows.Forms.Label
        Me.TAB_CoursesComplete = New System.Windows.Forms.TabPage
        Me.LBL_CoursesCompleteList = New System.Windows.Forms.Label
        Me.LST_status = New System.Windows.Forms.ListBox
        Me.TAB_Student = New System.Windows.Forms.TabControl
        Me.TAB_StudentSelect = New System.Windows.Forms.TabPage
        Me.TXT_StudentSelect_StudentPassWord = New System.Windows.Forms.TextBox
        Me.TXT_StudentSelect_StudentUserName = New System.Windows.Forms.TextBox
        Me.LBL_StudentSelect_StudentPassWord = New System.Windows.Forms.Label
        Me.LBL_StudentSelect_StudentUserName = New System.Windows.Forms.Label
        Me.BTN_StudentSelect_SignOn = New System.Windows.Forms.Button
        Me.BTN_StudentSelect_SignUp = New System.Windows.Forms.Button
        Me.TAB_StudentDetail = New System.Windows.Forms.TabPage
        Me.BTN_StudentDetail_Save = New System.Windows.Forms.Button
        Me.TXT_StudentDetail_StudentPassWord = New System.Windows.Forms.TextBox
        Me.TXT_StudentDetail_StudentUserName = New System.Windows.Forms.TextBox
        Me.BTN_About_Update = New System.Windows.Forms.Button
        Me.LBL_StudentDetail_StudentPassWord = New System.Windows.Forms.Label
        Me.LBL_StudentDetail_StudentUserName = New System.Windows.Forms.Label
        Me.BTN_StudentDetail_SignOut = New System.Windows.Forms.Button
        Me.TAB_StudentDegree = New System.Windows.Forms.TabPage
        Me.LST_StudentDegree = New System.Windows.Forms.ListBox
        Me.BTN_StudentDegree_Save = New System.Windows.Forms.Button
        Me.CMB_StudentDegreeList = New System.Windows.Forms.ComboBox
        Me.LBL_StudentDegree = New System.Windows.Forms.Label
        Me.LST_Decision = New System.Windows.Forms.ListView
        Me.BTN_DecisionHead = New System.Windows.Forms.Button
        Me.BTN_DecisionRise = New System.Windows.Forms.Button
        Me.BTN_DecisionTail = New System.Windows.Forms.Button
        Me.BTN_DecisionFall = New System.Windows.Forms.Button
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TAB_Enrollment = New System.Windows.Forms.TabControl
        Me.LST_Enrollment = New System.Windows.Forms.TabPage
        Me.TAB_Courses.SuspendLayout()
        Me.TAB_CoursesRequired.SuspendLayout()
        Me.TAB_CoursesPossible.SuspendLayout()
        Me.TAB_CoursesComplete.SuspendLayout()
        Me.TAB_Student.SuspendLayout()
        Me.TAB_StudentSelect.SuspendLayout()
        Me.TAB_StudentDetail.SuspendLayout()
        Me.TAB_StudentDegree.SuspendLayout()
        Me.TAB_Enrollment.SuspendLayout()
        Me.LST_Enrollment.SuspendLayout()
        Me.SuspendLayout()
        '
        'LBL_CoursesRequiredRequisites
        '
        Me.LBL_CoursesRequiredRequisites.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CoursesRequiredRequisites.Name = "LBL_CoursesRequiredRequisites"
        Me.LBL_CoursesRequiredRequisites.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesRequiredRequisites.TabIndex = 4
        Me.LBL_CoursesRequiredRequisites.Text = "Class Requirement(s)"
        Me.LBL_CoursesRequiredRequisites.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_CoursesRequiredList
        '
        Me.LST_CoursesRequiredList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CoursesRequiredList.Name = "LST_CoursesRequiredList"
        Me.LST_CoursesRequiredList.Size = New System.Drawing.Size(128, 147)
        Me.LST_CoursesRequiredList.TabIndex = 0
        '
        'LBL_CoursesRequiredName
        '
        Me.LBL_CoursesRequiredName.Location = New System.Drawing.Point(144, 16)
        Me.LBL_CoursesRequiredName.Name = "LBL_CoursesRequiredName"
        Me.LBL_CoursesRequiredName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesRequiredName.TabIndex = 2
        Me.LBL_CoursesRequiredName.Text = "Selected Course"
        Me.LBL_CoursesRequiredName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CoursesRequiredName
        '
        Me.TXT_CoursesRequiredName.Enabled = False
        Me.TXT_CoursesRequiredName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CoursesRequiredName.Multiline = True
        Me.TXT_CoursesRequiredName.Name = "TXT_CoursesRequiredName"
        Me.TXT_CoursesRequiredName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CoursesRequiredName.TabIndex = 3
        Me.TXT_CoursesRequiredName.Text = ""
        '
        'LST_CoursesPossibleList
        '
        Me.LST_CoursesPossibleList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CoursesPossibleList.Name = "LST_CoursesPossibleList"
        Me.LST_CoursesPossibleList.Size = New System.Drawing.Size(128, 173)
        Me.LST_CoursesPossibleList.TabIndex = 6
        '
        'TXT_CoursesPossibleTermPart
        '
        Me.TXT_CoursesPossibleTermPart.Location = New System.Drawing.Point(144, 160)
        Me.TXT_CoursesPossibleTermPart.Name = "TXT_CoursesPossibleTermPart"
        Me.TXT_CoursesPossibleTermPart.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CoursesPossibleTermPart.TabIndex = 5
        Me.TXT_CoursesPossibleTermPart.Text = ""
        '
        'TXT_CoursesPossibleTermYear
        '
        Me.TXT_CoursesPossibleTermYear.Location = New System.Drawing.Point(144, 104)
        Me.TXT_CoursesPossibleTermYear.Name = "TXT_CoursesPossibleTermYear"
        Me.TXT_CoursesPossibleTermYear.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CoursesPossibleTermYear.TabIndex = 4
        Me.TXT_CoursesPossibleTermYear.Text = ""
        '
        'LBL_CoursesPossibleTermYear
        '
        Me.LBL_CoursesPossibleTermYear.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CoursesPossibleTermYear.Name = "LBL_CoursesPossibleTermYear"
        Me.LBL_CoursesPossibleTermYear.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesPossibleTermYear.TabIndex = 3
        Me.LBL_CoursesPossibleTermYear.Text = "Year Enrolled"
        Me.LBL_CoursesPossibleTermYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CoursesPossibleName
        '
        Me.TXT_CoursesPossibleName.Enabled = False
        Me.TXT_CoursesPossibleName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CoursesPossibleName.Multiline = True
        Me.TXT_CoursesPossibleName.Name = "TXT_CoursesPossibleName"
        Me.TXT_CoursesPossibleName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CoursesPossibleName.TabIndex = 2
        Me.TXT_CoursesPossibleName.Text = ""
        '
        'LBL_CoursesPossibleName
        '
        Me.LBL_CoursesPossibleName.Location = New System.Drawing.Point(144, 16)
        Me.LBL_CoursesPossibleName.Name = "LBL_CoursesPossibleName"
        Me.LBL_CoursesPossibleName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesPossibleName.TabIndex = 1
        Me.LBL_CoursesPossibleName.Text = "Selected Course"
        Me.LBL_CoursesPossibleName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_CoursesPossible_Save
        '
        Me.BTN_CoursesPossible_Save.Location = New System.Drawing.Point(144, 192)
        Me.BTN_CoursesPossible_Save.Name = "BTN_CoursesPossible_Save"
        Me.BTN_CoursesPossible_Save.Size = New System.Drawing.Size(128, 23)
        Me.BTN_CoursesPossible_Save.TabIndex = 1
        Me.BTN_CoursesPossible_Save.Text = "Save Changes"
        '
        'LST_CoursesCompleteList
        '
        Me.LST_CoursesCompleteList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CoursesCompleteList.Name = "LST_CoursesCompleteList"
        Me.LST_CoursesCompleteList.Size = New System.Drawing.Size(128, 160)
        Me.LST_CoursesCompleteList.TabIndex = 6
        '
        'TXT_CourseCompleteTermPart
        '
        Me.TXT_CourseCompleteTermPart.Enabled = False
        Me.TXT_CourseCompleteTermPart.Location = New System.Drawing.Point(144, 160)
        Me.TXT_CourseCompleteTermPart.Name = "TXT_CourseCompleteTermPart"
        Me.TXT_CourseCompleteTermPart.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CourseCompleteTermPart.TabIndex = 5
        Me.TXT_CourseCompleteTermPart.Text = ""
        '
        'TXT_done_selected_termyear
        '
        Me.TXT_done_selected_termyear.Enabled = False
        Me.TXT_done_selected_termyear.Location = New System.Drawing.Point(144, 104)
        Me.TXT_done_selected_termyear.Name = "TXT_done_selected_termyear"
        Me.TXT_done_selected_termyear.Size = New System.Drawing.Size(128, 20)
        Me.TXT_done_selected_termyear.TabIndex = 4
        Me.TXT_done_selected_termyear.Text = ""
        '
        'LBL_CourseCompleteName
        '
        Me.LBL_CourseCompleteName.Location = New System.Drawing.Point(152, 16)
        Me.LBL_CourseCompleteName.Name = "LBL_CourseCompleteName"
        Me.LBL_CourseCompleteName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteName.TabIndex = 1
        Me.LBL_CourseCompleteName.Text = "Selected Course"
        Me.LBL_CourseCompleteName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CourseCompleteName
        '
        Me.TXT_CourseCompleteName.Enabled = False
        Me.TXT_CourseCompleteName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CourseCompleteName.Multiline = True
        Me.TXT_CourseCompleteName.Name = "TXT_CourseCompleteName"
        Me.TXT_CourseCompleteName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CourseCompleteName.TabIndex = 2
        Me.TXT_CourseCompleteName.Text = ""
        '
        'LBL_CourseCompleteTermYear
        '
        Me.LBL_CourseCompleteTermYear.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CourseCompleteTermYear.Name = "LBL_CourseCompleteTermYear"
        Me.LBL_CourseCompleteTermYear.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteTermYear.TabIndex = 3
        Me.LBL_CourseCompleteTermYear.Text = "Year Enrolled"
        Me.LBL_CourseCompleteTermYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_CoursesRequiredRequisites
        '
        Me.LST_CoursesRequiredRequisites.Enabled = False
        Me.LST_CoursesRequiredRequisites.Location = New System.Drawing.Point(144, 112)
        Me.LST_CoursesRequiredRequisites.Name = "LST_CoursesRequiredRequisites"
        Me.LST_CoursesRequiredRequisites.Size = New System.Drawing.Size(128, 69)
        Me.LST_CoursesRequiredRequisites.TabIndex = 11
        '
        'LBL_CoursesPossibleTermPart
        '
        Me.LBL_CoursesPossibleTermPart.Location = New System.Drawing.Point(144, 136)
        Me.LBL_CoursesPossibleTermPart.Name = "LBL_CoursesPossibleTermPart"
        Me.LBL_CoursesPossibleTermPart.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesPossibleTermPart.TabIndex = 12
        Me.LBL_CoursesPossibleTermPart.Text = "Term Enrolled"
        Me.LBL_CoursesPossibleTermPart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_CourseCompleteTermPart
        '
        Me.LBL_CourseCompleteTermPart.Location = New System.Drawing.Point(144, 136)
        Me.LBL_CourseCompleteTermPart.Name = "LBL_CourseCompleteTermPart"
        Me.LBL_CourseCompleteTermPart.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteTermPart.TabIndex = 13
        Me.LBL_CourseCompleteTermPart.Text = "Term Enrolled"
        Me.LBL_CourseCompleteTermPart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_Courses
        '
        Me.TAB_Courses.Controls.Add(Me.TAB_CoursesRequired)
        Me.TAB_Courses.Controls.Add(Me.TAB_CoursesPossible)
        Me.TAB_Courses.Controls.Add(Me.TAB_CoursesComplete)
        Me.TAB_Courses.Location = New System.Drawing.Point(472, 16)
        Me.TAB_Courses.Multiline = True
        Me.TAB_Courses.Name = "TAB_Courses"
        Me.TAB_Courses.SelectedIndex = 0
        Me.TAB_Courses.Size = New System.Drawing.Size(296, 248)
        Me.TAB_Courses.TabIndex = 14
        '
        'TAB_CoursesRequired
        '
        Me.TAB_CoursesRequired.Controls.Add(Me.LBL_CoursesRequiredList)
        Me.TAB_CoursesRequired.Controls.Add(Me.LST_CoursesRequiredList)
        Me.TAB_CoursesRequired.Controls.Add(Me.LBL_CoursesRequiredName)
        Me.TAB_CoursesRequired.Controls.Add(Me.TXT_CoursesRequiredName)
        Me.TAB_CoursesRequired.Controls.Add(Me.LBL_CoursesRequiredRequisites)
        Me.TAB_CoursesRequired.Controls.Add(Me.LST_CoursesRequiredRequisites)
        Me.TAB_CoursesRequired.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CoursesRequired.Name = "TAB_CoursesRequired"
        Me.TAB_CoursesRequired.Size = New System.Drawing.Size(288, 222)
        Me.TAB_CoursesRequired.TabIndex = 0
        Me.TAB_CoursesRequired.Text = "Courses Required"
        '
        'LBL_CoursesRequiredList
        '
        Me.LBL_CoursesRequiredList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CoursesRequiredList.Name = "LBL_CoursesRequiredList"
        Me.LBL_CoursesRequiredList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesRequiredList.TabIndex = 0
        Me.LBL_CoursesRequiredList.Text = "Required Courses"
        Me.LBL_CoursesRequiredList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_CoursesPossible
        '
        Me.TAB_CoursesPossible.Controls.Add(Me.LBL_CoursesPossibleList)
        Me.TAB_CoursesPossible.Controls.Add(Me.LST_CoursesPossibleList)
        Me.TAB_CoursesPossible.Controls.Add(Me.LBL_CoursesPossibleTermPart)
        Me.TAB_CoursesPossible.Controls.Add(Me.TXT_CoursesPossibleTermPart)
        Me.TAB_CoursesPossible.Controls.Add(Me.TXT_CoursesPossibleTermYear)
        Me.TAB_CoursesPossible.Controls.Add(Me.LBL_CoursesPossibleTermYear)
        Me.TAB_CoursesPossible.Controls.Add(Me.TXT_CoursesPossibleName)
        Me.TAB_CoursesPossible.Controls.Add(Me.LBL_CoursesPossibleName)
        Me.TAB_CoursesPossible.Controls.Add(Me.BTN_CoursesPossible_Save)
        Me.TAB_CoursesPossible.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CoursesPossible.Name = "TAB_CoursesPossible"
        Me.TAB_CoursesPossible.Size = New System.Drawing.Size(288, 222)
        Me.TAB_CoursesPossible.TabIndex = 1
        Me.TAB_CoursesPossible.Text = "Courses Possible"
        '
        'LBL_CoursesPossibleList
        '
        Me.LBL_CoursesPossibleList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CoursesPossibleList.Name = "LBL_CoursesPossibleList"
        Me.LBL_CoursesPossibleList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesPossibleList.TabIndex = 13
        Me.LBL_CoursesPossibleList.Text = "Possible Courses"
        Me.LBL_CoursesPossibleList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_CoursesComplete
        '
        Me.TAB_CoursesComplete.Controls.Add(Me.LBL_CoursesCompleteList)
        Me.TAB_CoursesComplete.Controls.Add(Me.TXT_CourseCompleteTermPart)
        Me.TAB_CoursesComplete.Controls.Add(Me.TXT_done_selected_termyear)
        Me.TAB_CoursesComplete.Controls.Add(Me.LBL_CourseCompleteName)
        Me.TAB_CoursesComplete.Controls.Add(Me.TXT_CourseCompleteName)
        Me.TAB_CoursesComplete.Controls.Add(Me.LBL_CourseCompleteTermYear)
        Me.TAB_CoursesComplete.Controls.Add(Me.LBL_CourseCompleteTermPart)
        Me.TAB_CoursesComplete.Controls.Add(Me.LST_CoursesCompleteList)
        Me.TAB_CoursesComplete.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CoursesComplete.Name = "TAB_CoursesComplete"
        Me.TAB_CoursesComplete.Size = New System.Drawing.Size(288, 222)
        Me.TAB_CoursesComplete.TabIndex = 2
        Me.TAB_CoursesComplete.Text = "Courses Complete"
        '
        'LBL_CoursesCompleteList
        '
        Me.LBL_CoursesCompleteList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CoursesCompleteList.Name = "LBL_CoursesCompleteList"
        Me.LBL_CoursesCompleteList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursesCompleteList.TabIndex = 14
        Me.LBL_CoursesCompleteList.Text = "Complete Courses"
        Me.LBL_CoursesCompleteList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_status
        '
        Me.LST_status.Location = New System.Drawing.Point(8, 280)
        Me.LST_status.Name = "LST_status"
        Me.LST_status.Size = New System.Drawing.Size(1312, 173)
        Me.LST_status.TabIndex = 15
        '
        'TAB_Student
        '
        Me.TAB_Student.Controls.Add(Me.TAB_StudentSelect)
        Me.TAB_Student.Controls.Add(Me.TAB_StudentDetail)
        Me.TAB_Student.Controls.Add(Me.TAB_StudentDegree)
        Me.TAB_Student.Location = New System.Drawing.Point(8, 16)
        Me.TAB_Student.Multiline = True
        Me.TAB_Student.Name = "TAB_Student"
        Me.TAB_Student.SelectedIndex = 0
        Me.TAB_Student.Size = New System.Drawing.Size(256, 248)
        Me.TAB_Student.TabIndex = 16
        '
        'TAB_StudentSelect
        '
        Me.TAB_StudentSelect.Controls.Add(Me.TXT_StudentSelect_StudentPassWord)
        Me.TAB_StudentSelect.Controls.Add(Me.TXT_StudentSelect_StudentUserName)
        Me.TAB_StudentSelect.Controls.Add(Me.LBL_StudentSelect_StudentPassWord)
        Me.TAB_StudentSelect.Controls.Add(Me.LBL_StudentSelect_StudentUserName)
        Me.TAB_StudentSelect.Controls.Add(Me.BTN_StudentSelect_SignOn)
        Me.TAB_StudentSelect.Controls.Add(Me.BTN_StudentSelect_SignUp)
        Me.TAB_StudentSelect.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentSelect.Name = "TAB_StudentSelect"
        Me.TAB_StudentSelect.Size = New System.Drawing.Size(248, 222)
        Me.TAB_StudentSelect.TabIndex = 0
        Me.TAB_StudentSelect.Text = "Student Select"
        '
        'TXT_StudentSelect_StudentPassWord
        '
        Me.TXT_StudentSelect_StudentPassWord.Location = New System.Drawing.Point(16, 120)
        Me.TXT_StudentSelect_StudentPassWord.Multiline = True
        Me.TXT_StudentSelect_StudentPassWord.Name = "TXT_StudentSelect_StudentPassWord"
        Me.TXT_StudentSelect_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.TXT_StudentSelect_StudentPassWord.TabIndex = 5
        Me.TXT_StudentSelect_StudentPassWord.Text = "TextBox1"
        '
        'TXT_StudentSelect_StudentUserName
        '
        Me.TXT_StudentSelect_StudentUserName.Location = New System.Drawing.Point(16, 48)
        Me.TXT_StudentSelect_StudentUserName.Multiline = True
        Me.TXT_StudentSelect_StudentUserName.Name = "TXT_StudentSelect_StudentUserName"
        Me.TXT_StudentSelect_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.TXT_StudentSelect_StudentUserName.TabIndex = 4
        Me.TXT_StudentSelect_StudentUserName.Text = "TextBox1"
        '
        'LBL_StudentSelect_StudentPassWord
        '
        Me.LBL_StudentSelect_StudentPassWord.Location = New System.Drawing.Point(8, 88)
        Me.LBL_StudentSelect_StudentPassWord.Name = "LBL_StudentSelect_StudentPassWord"
        Me.LBL_StudentSelect_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentSelect_StudentPassWord.TabIndex = 3
        Me.LBL_StudentSelect_StudentPassWord.Text = "PassWord"
        Me.LBL_StudentSelect_StudentPassWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_StudentSelect_StudentUserName
        '
        Me.LBL_StudentSelect_StudentUserName.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentSelect_StudentUserName.Name = "LBL_StudentSelect_StudentUserName"
        Me.LBL_StudentSelect_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentSelect_StudentUserName.TabIndex = 2
        Me.LBL_StudentSelect_StudentUserName.Text = "UserName"
        Me.LBL_StudentSelect_StudentUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_StudentSelect_SignOn
        '
        Me.BTN_StudentSelect_SignOn.Location = New System.Drawing.Point(160, 160)
        Me.BTN_StudentSelect_SignOn.Name = "BTN_StudentSelect_SignOn"
        Me.BTN_StudentSelect_SignOn.TabIndex = 1
        Me.BTN_StudentSelect_SignOn.Text = "Sign On"
        '
        'BTN_StudentSelect_SignUp
        '
        Me.BTN_StudentSelect_SignUp.Location = New System.Drawing.Point(16, 160)
        Me.BTN_StudentSelect_SignUp.Name = "BTN_StudentSelect_SignUp"
        Me.BTN_StudentSelect_SignUp.TabIndex = 0
        Me.BTN_StudentSelect_SignUp.Text = "Sign Up"
        '
        'TAB_StudentDetail
        '
        Me.TAB_StudentDetail.Controls.Add(Me.BTN_StudentDetail_Save)
        Me.TAB_StudentDetail.Controls.Add(Me.TXT_StudentDetail_StudentPassWord)
        Me.TAB_StudentDetail.Controls.Add(Me.TXT_StudentDetail_StudentUserName)
        Me.TAB_StudentDetail.Controls.Add(Me.BTN_About_Update)
        Me.TAB_StudentDetail.Controls.Add(Me.LBL_StudentDetail_StudentPassWord)
        Me.TAB_StudentDetail.Controls.Add(Me.LBL_StudentDetail_StudentUserName)
        Me.TAB_StudentDetail.Controls.Add(Me.BTN_StudentDetail_SignOut)
        Me.TAB_StudentDetail.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentDetail.Name = "TAB_StudentDetail"
        Me.TAB_StudentDetail.Size = New System.Drawing.Size(248, 222)
        Me.TAB_StudentDetail.TabIndex = 1
        Me.TAB_StudentDetail.Text = "Student Detail"
        '
        'BTN_StudentDetail_Save
        '
        Me.BTN_StudentDetail_Save.Location = New System.Drawing.Point(160, 160)
        Me.BTN_StudentDetail_Save.Name = "BTN_StudentDetail_Save"
        Me.BTN_StudentDetail_Save.TabIndex = 28
        Me.BTN_StudentDetail_Save.Text = "Save"
        '
        'TXT_StudentDetail_StudentPassWord
        '
        Me.TXT_StudentDetail_StudentPassWord.Location = New System.Drawing.Point(16, 120)
        Me.TXT_StudentDetail_StudentPassWord.Name = "TXT_StudentDetail_StudentPassWord"
        Me.TXT_StudentDetail_StudentPassWord.Size = New System.Drawing.Size(218, 20)
        Me.TXT_StudentDetail_StudentPassWord.TabIndex = 11
        Me.TXT_StudentDetail_StudentPassWord.Text = "TextBox1"
        '
        'TXT_StudentDetail_StudentUserName
        '
        Me.TXT_StudentDetail_StudentUserName.Location = New System.Drawing.Point(16, 48)
        Me.TXT_StudentDetail_StudentUserName.Name = "TXT_StudentDetail_StudentUserName"
        Me.TXT_StudentDetail_StudentUserName.Size = New System.Drawing.Size(218, 20)
        Me.TXT_StudentDetail_StudentUserName.TabIndex = 10
        Me.TXT_StudentDetail_StudentUserName.Text = "TextBox1"
        '
        'BTN_About_Update
        '
        Me.BTN_About_Update.Location = New System.Drawing.Point(64, 240)
        Me.BTN_About_Update.Name = "BTN_About_Update"
        Me.BTN_About_Update.TabIndex = 9
        Me.BTN_About_Update.Text = "Update"
        '
        'LBL_StudentDetail_StudentPassWord
        '
        Me.LBL_StudentDetail_StudentPassWord.Location = New System.Drawing.Point(8, 88)
        Me.LBL_StudentDetail_StudentPassWord.Name = "LBL_StudentDetail_StudentPassWord"
        Me.LBL_StudentDetail_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentDetail_StudentPassWord.TabIndex = 8
        Me.LBL_StudentDetail_StudentPassWord.Text = "PassWord"
        Me.LBL_StudentDetail_StudentPassWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_StudentDetail_StudentUserName
        '
        Me.LBL_StudentDetail_StudentUserName.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentDetail_StudentUserName.Name = "LBL_StudentDetail_StudentUserName"
        Me.LBL_StudentDetail_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentDetail_StudentUserName.TabIndex = 7
        Me.LBL_StudentDetail_StudentUserName.Text = "UserName"
        Me.LBL_StudentDetail_StudentUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_StudentDetail_SignOut
        '
        Me.BTN_StudentDetail_SignOut.Location = New System.Drawing.Point(16, 160)
        Me.BTN_StudentDetail_SignOut.Name = "BTN_StudentDetail_SignOut"
        Me.BTN_StudentDetail_SignOut.TabIndex = 27
        Me.BTN_StudentDetail_SignOut.Text = "Sign Out"
        '
        'TAB_StudentDegree
        '
        Me.TAB_StudentDegree.Controls.Add(Me.LST_StudentDegree)
        Me.TAB_StudentDegree.Controls.Add(Me.BTN_StudentDegree_Save)
        Me.TAB_StudentDegree.Controls.Add(Me.CMB_StudentDegreeList)
        Me.TAB_StudentDegree.Controls.Add(Me.LBL_StudentDegree)
        Me.TAB_StudentDegree.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentDegree.Name = "TAB_StudentDegree"
        Me.TAB_StudentDegree.Size = New System.Drawing.Size(248, 222)
        Me.TAB_StudentDegree.TabIndex = 2
        Me.TAB_StudentDegree.Text = "Student Degree"
        '
        'LST_StudentDegree
        '
        Me.LST_StudentDegree.Location = New System.Drawing.Point(16, 48)
        Me.LST_StudentDegree.Name = "LST_StudentDegree"
        Me.LST_StudentDegree.Size = New System.Drawing.Size(216, 56)
        Me.LST_StudentDegree.TabIndex = 23
        '
        'BTN_StudentDegree_Save
        '
        Me.BTN_StudentDegree_Save.Location = New System.Drawing.Point(88, 160)
        Me.BTN_StudentDegree_Save.Name = "BTN_StudentDegree_Save"
        Me.BTN_StudentDegree_Save.Size = New System.Drawing.Size(77, 24)
        Me.BTN_StudentDegree_Save.TabIndex = 22
        Me.BTN_StudentDegree_Save.Text = "Degree Add"
        '
        'CMB_StudentDegreeList
        '
        Me.CMB_StudentDegreeList.Location = New System.Drawing.Point(16, 120)
        Me.CMB_StudentDegreeList.Name = "CMB_StudentDegreeList"
        Me.CMB_StudentDegreeList.Size = New System.Drawing.Size(216, 21)
        Me.CMB_StudentDegreeList.TabIndex = 8
        '
        'LBL_StudentDegree
        '
        Me.LBL_StudentDegree.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentDegree.Name = "LBL_StudentDegree"
        Me.LBL_StudentDegree.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentDegree.TabIndex = 0
        Me.LBL_StudentDegree.Text = "Degree"
        Me.LBL_StudentDegree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_Decision
        '
        Me.LST_Decision.Location = New System.Drawing.Point(64, 8)
        Me.LST_Decision.Name = "LST_Decision"
        Me.LST_Decision.Size = New System.Drawing.Size(104, 184)
        Me.LST_Decision.TabIndex = 17
        '
        'BTN_DecisionHead
        '
        Me.BTN_DecisionHead.Location = New System.Drawing.Point(8, 8)
        Me.BTN_DecisionHead.Name = "BTN_DecisionHead"
        Me.BTN_DecisionHead.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionHead.TabIndex = 21
        Me.BTN_DecisionHead.Text = "Start"
        '
        'BTN_DecisionRise
        '
        Me.BTN_DecisionRise.Location = New System.Drawing.Point(8, 40)
        Me.BTN_DecisionRise.Name = "BTN_DecisionRise"
        Me.BTN_DecisionRise.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionRise.TabIndex = 22
        Me.BTN_DecisionRise.Text = "Prior"
        '
        'BTN_DecisionTail
        '
        Me.BTN_DecisionTail.Location = New System.Drawing.Point(8, 168)
        Me.BTN_DecisionTail.Name = "BTN_DecisionTail"
        Me.BTN_DecisionTail.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionTail.TabIndex = 23
        Me.BTN_DecisionTail.Text = "Final"
        '
        'BTN_DecisionFall
        '
        Me.BTN_DecisionFall.Location = New System.Drawing.Point(8, 136)
        Me.BTN_DecisionFall.Name = "BTN_DecisionFall"
        Me.BTN_DecisionFall.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionFall.TabIndex = 24
        Me.BTN_DecisionFall.Text = "After"
        '
        'TabPage1
        '
        Me.TabPage1.Location = New System.Drawing.Point(4, 218)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(176, 26)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Decisions"
        '
        'TAB_Enrollment
        '
        Me.TAB_Enrollment.Controls.Add(Me.LST_Enrollment)
        Me.TAB_Enrollment.Location = New System.Drawing.Point(272, 16)
        Me.TAB_Enrollment.Multiline = True
        Me.TAB_Enrollment.Name = "TAB_Enrollment"
        Me.TAB_Enrollment.SelectedIndex = 0
        Me.TAB_Enrollment.Size = New System.Drawing.Size(184, 248)
        Me.TAB_Enrollment.TabIndex = 26
        '
        'LST_Enrollment
        '
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionFall)
        Me.LST_Enrollment.Controls.Add(Me.LST_Decision)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionHead)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionRise)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionTail)
        Me.LST_Enrollment.Location = New System.Drawing.Point(4, 22)
        Me.LST_Enrollment.Name = "LST_Enrollment"
        Me.LST_Enrollment.Size = New System.Drawing.Size(176, 222)
        Me.LST_Enrollment.TabIndex = 0
        Me.LST_Enrollment.Text = "Enrollment"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1370, 684)
        Me.Controls.Add(Me.TAB_Enrollment)
        Me.Controls.Add(Me.TAB_Student)
        Me.Controls.Add(Me.LST_status)
        Me.Controls.Add(Me.TAB_Courses)
        Me.MaximumSize = New System.Drawing.Size(2000, 720)
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.Text = "LongView"
        Me.TAB_Courses.ResumeLayout(False)
        Me.TAB_CoursesRequired.ResumeLayout(False)
        Me.TAB_CoursesPossible.ResumeLayout(False)
        Me.TAB_CoursesComplete.ResumeLayout(False)
        Me.TAB_Student.ResumeLayout(False)
        Me.TAB_StudentSelect.ResumeLayout(False)
        Me.TAB_StudentDetail.ResumeLayout(False)
        Me.TAB_StudentDegree.ResumeLayout(False)
        Me.TAB_Enrollment.ResumeLayout(False)
        Me.LST_Enrollment.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LST_status.Items.Add(connString)

    End Sub

    Private Sub StudentSelect_Make()

        'SignUp

        StudentIndex = Student_Find()
        LST_status.Items.Add("in StudentSelect_Make() StudentIndex::" & StudentIndex)

        If (StudentIndex > 0) Then
            ' Atleast one Student with Credentials (studentusername, studentpassword) Found
            ' Dialog (this accoung exists, please logon instead)
            LST_status.Items.Add("Student Currently Exists")
            LST_status.Items.Add("Please Signon Instead")
        Else
            ' No Student with Credentials (studentusername, studentpassword) Found
            ' Create the Student
            LST_status.Items.Add("Student Does Not Currently Exist")
            LST_status.Items.Add("Creating the Student")

            StudentSelect_Save()
        End If
    End Sub


    Private Sub StudentSelect_Load()
        ' SignOn
        
        StudentIndex = Student_Find()

        If (StudentIndex > 0) Then
            ' Atleast one Student with Credentials (studentusername, studentpassword) Found
            ' Dialog (this accoungt exists, please logon instead)
            LST_status.Items.Add("Student Currently Exists")
            LST_status.Items.Add("Student Is Now Signed On")
        Else
            ' No Student with Credentials (studentusername, studentpassword) Found
            ' Create the Student
            LST_status.Items.Add("Student Does Not Currently Exist")
            LST_status.Items.Add("Please Signup")
        End If

        EnrollmentStep_Load()

    End Sub

    Private Sub StudentSelect_Save()

        Dim tmpStudentIndex As Integer = -1

        Dim QRY As String = ""
        QRY = QRY_StudentSelect_Save
        QRY = QRY.Replace("{StudentUserName}", TXT_StudentSelect_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentSelect_StudentPassWord.Text)

        ANS_StudentSelect_Save = Data_Load(QRY, dtacon)

        StudentIndex = Student_Find()

        If (tmpStudentIndex <> -1) Then
            LST_status.Items.Add("Student Account was successfully created")
        Else
            LST_status.Items.Add("Student Account Was Unable to be saved")
        End If

    End Sub

    Private Function Student_Find()

        Dim tmpStudentIndex As Integer = -1

        Dim QRY As String = ""

        'QRY = "SELECT StudentIndex FROM Students WHERE 0 = 0 AND StudentUserName = '@StudentUserName' AND StudentPassWord = '@StudentPassWord"

        QRY = QRY_Student_Find

        '
        'LST_status.Items.Add(QRY)
        '

        QRY = QRY.Replace("{StudentUserName}", TXT_StudentSelect_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentSelect_StudentPassWord.Text)

        '
        'LST_status.Items.Add(QRY)
        '

        If Not (IsNothing(ANS_Student_Find)) Then
            ANS_Student_Find.Clear()
        End If


        ANS_Student_Find = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_Student_Find.Rows
            tmpStudentIndex = row.Item("StudentIndex")
        Next row


        ''
        'If tmpStudentIndex <> -1 Then
        'LST_status.Items.Add("StudentFound=T")
        'Else
        '    LST_status.Items.Add("StudentFound=F")
        'End If
        ''
        'LST_status.Items.Add(tmpStudentIndex)

        Return tmpStudentIndex

    End Function


    Private Sub BTN_Select_SignUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentSelect_SignUp.Click
        StudentSelect_Make()
    End Sub

    Private Sub BTN_Select_SignOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentSelect_SignOn.Click
        StudentSelect_Load()
    End Sub

    

    Public Sub TAB_StudentSelect_Show()
        TAB_StudentSelect_Load()
        TAB_StudentSelect_Fill()
    End Sub
    Public Sub TAB_StudentSelect_Load()


    End Sub
    Public Sub TAB_StudentSelect_Fill()

    End Sub
    Public Sub TAB_StudentSelect_Hide()

    End Sub

    Public Sub TAB_StudentDetail_Show()
        TAB_StudentDetail_Load()
        TAB_StudentDetail_Fill()
    End Sub

    Public Sub TAB_StudentDetail_Load()
        Dim QRY As String = QRY_StudentDetail_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentDetail_Load = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_StudentDetail_Load.Rows
            If IsDBNull(row.Item("StudentNamePublic")) Then
                StudentNamePublic = ""
            Else
                StudentNamePublic = row.Item("StudentNamePublic")
            End If
        Next row
    End Sub

    Public Sub TAB_StudentDetail_Fill()

        'TXT_StudentDetail_StudentNamePublic.Text = StudentNamePublic

    End Sub

    Public Sub TAB_StudentDegree_Show()
        TAB_StudentDegree_Load()
    End Sub
    Public Sub TAB_StudentDegree_Load()
        TAB_StudentDegreeItem_Load()
        TAB_StudentDegreeList_Load()
    End Sub

    Public Sub TAB_StudentDegreeItem_Load()
        Dim QRY As String = QRY_StudentDegreeItem_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentDegreeItem_Load = Data_Load(QRY, dtacon)

        LST_StudentDegree.Items.Clear()

        For Each row As DataRow In ANS_StudentDegreeItem_Load.Rows
            LST_StudentDegree.Items.Add(row.Item("MajorTitle"))
        Next row
    End Sub

    Public Sub TAB_StudentDegreeList_Load()
        Dim QRY As String = QRY_StudentDegreeList_Load

        QRY = QRY.Replace("{StudentIndex}", "StudentIndex")

        ANS_StudentDegreeList_Load = Data_Load(QRY, dtacon)

        CMB_StudentDegreeList.Items.Clear()

        For Each row As DataRow In ANS_StudentDegreeList_Load.Rows
            CMB_StudentDegreeList.Items.Add(row.Item("MajorTitle"))
            CMB_StudentDegreeList.SelectedItem = row.Item("MajorTitle")
        Next row
    End Sub

    Private Sub TAB_Student_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TAB_Student.Click
        If TAB_Student.SelectedIndex = 0 Then
            TAB_StudentSelect_Show()
        End If
        If TAB_Student.SelectedIndex = 1 Then
            TAB_StudentDetail_Show()
        End If
        If TAB_Student.SelectedIndex = 2 Then
            TAB_StudentDegree_Show()
        End If
    End Sub

    Private Sub TAB_Courses_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TAB_Courses.Click
        If TAB_Courses.SelectedIndex = 0 Then
            TAB_CoursesRequiredList_Show()
        End If
        If TAB_Courses.SelectedIndex = 1 Then
            TAB_CoursesPossibleList_Show()
        End If
        If TAB_Courses.SelectedIndex = 2 Then
            TAB_CoursesCompleteList_Show()
        End If
    End Sub

    Public Sub TAB_CoursesRequiredList_Show()
        TAB_CoursesRequiredList_Load()
    End Sub
    Public Sub TAB_CoursesRequiredList_Load()
        Dim QRY As String = QRY_CourseRequiredList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_CourseRequiredList_Load = Data_Load(QRY, dtacon)

        LST_CoursesRequiredList.Items.Clear()

        For Each row As DataRow In ANS_CourseRequiredList_Load.Rows
            LST_CoursesRequiredList.Items.Add(row.Item("CourseName"))
        Next row
    End Sub

    Public Sub TAB_CoursesPossibleList_Show()
        TAB_CoursesPossibleList_Load()
    End Sub
    Public Sub TAB_CoursesPossibleList_Load()
        Dim QRY As String = QRY_CourseCompleteList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_CourseCompleteList_Load = Data_Load(QRY, dtacon)

        LST_CoursesPossibleList.Items.Clear()

        For Each row As DataRow In ANS_CourseCompleteList_Load.Rows
            LST_CoursesPossibleList.Items.Add(row.Item("CourseName"))
        Next row
    End Sub

    Public Sub TAB_CoursesCompleteList_Show()
        TAB_CoursesCompleteList_Load()
    End Sub

    Public Sub TAB_CoursesCompleteList_Load()

        Dim QRY As String = QRY_CourseCompleteList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentDetail_Load = Data_Load(QRY, dtacon)

        LST_CoursesCompleteList.Items.Clear()

        For Each row As DataRow In ANS_StudentDetail_Load.Rows
            LST_CoursesCompleteList.Items.Add(row.Item("CourseName"))
        Next row

    End Sub

    Public Sub EnrollmentStep_Load()
        LST_Decision.Items.Clear()
        EnrollmentStepAbove_Load()
        EnrollmentStepTween_Load()
        EnrollmentStepBelow_Load()
    End Sub

    Public Sub EnrollmentStepAbove_Load()
        Dim QRY As String = QRY_EnrollmentStepAbove_Load

        QRY = QRY.Replace("{EnrollmentStepIndex}", EnrollmentStepIndex)

        ANS_EnrollmentStepAbove_Load = Data_Load(QRY, dtacon)
        '
        LST_status.Items.Add("ANS_EnrollmentStepAbove_Load.Rows.Count" & "::" & ANS_EnrollmentStepAbove_Load.Rows.Count)
        '

        For Each row As DataRow In ANS_EnrollmentStepAbove_Load.Rows
            LST_Decision.Items.Add(row.Item("EnrollmentStepName"))
        Next row
    End Sub

    Public Sub EnrollmentStepTween_Load()
        Dim QRY As String = QRY_EnrollmentStepTween_Load

        QRY = QRY.Replace("{EnrollmentStepIndex}", EnrollmentStepIndex)

        ANS_EnrollmentStepTween_Load = Data_Load(QRY, dtacon)

        '
        LST_status.Items.Add("ANS_EnrollmentStepTween_Load.Rows.Count" & "::" & ANS_EnrollmentStepTween_Load.Rows.Count())
        '

        For Each row As DataRow In ANS_EnrollmentStepTween_Load.Rows
            LST_Decision.Items.Add(row.Item("EnrollmentStepName"))
        Next row
    End Sub

    Public Sub EnrollmentStepBelow_Load()
        Dim QRY As String = QRY_EnrollmentStepBelow_Load

        QRY = QRY.Replace("{EnrollmentStepIndex}", EnrollmentStepIndex)

        ANS_EnrollmentStepBelow_Load = Data_Load(QRY, dtacon)
        '
        LST_status.Items.Add("ANS_EnrollmentStepBelow_Load.Rows.Count" & "::" & ANS_EnrollmentStepBelow_Load.Rows.Count())
        '

        For Each row As DataRow In ANS_EnrollmentStepBelow_Load.Rows
            LST_Decision.Items.Add(row.Item("EnrollmentStepName"))
        Next row
    End Sub
    Private Sub StudentDetail_Save()
        Dim QRY As String = QRY_StudentDetail_Save

        QRY = QRY.Replace("{StudentUserName}", TXT_StudentDetail_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentDetail_StudentPassWord.Text)
        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentDetail_Save = Data_Load(QRY, dtacon)

    End Sub

    Private Sub BTN_StudentDegree_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentDegree_Save.Click

        'LST_status.Items.Add("BTN_StudentDegree_Save_Click")

        Dim QRY As String = ""
        QRY = QRY_StudentDegree_Save

        'LST_status.Items.Add("BTN_StudentDegree_Save_Click")

        Dim SelectedDegreeValue As String = CMB_StudentDegreeList.SelectedValue
        Dim SelectedDegreeIndex As Integer = -1

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)
        QRY = QRY.Replace("{DegreeIndex}", SelectedDegreeIndex)

        LST_status.Items.Add("QRY::" & QRY)

        ANS_StudentDegree_Save = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_StudentDegree_Save.Rows
            LST_status.Items.Add("Inside Loop")
            LST_status.Items.Add("row.Item(`MajorName`)::" = row.Item("MajorName"))
            LST_status.Items.Add("SelectedDegreeValue::" = SelectedDegreeValue)
            If row.Item("MajorName") = SelectedDegreeValue Then
                SelectedDegreeIndex = row.Item("MajorIndex")
                '
                LST_status.Items.Add("Found Major Index")
                '
            End If
        Next row

        If (SelectedDegreeIndex <> -1) Then
            ANS_StudentDegree_Save = Data_Load(QRY, dtacon)
        End If





    End Sub

    Private Sub BTN_StudentDetail_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentDetail_Save.Click
        StudentDetail_Save()
    End Sub


    Public Function Data_Load(ByVal query As String, ByVal connection As OleDbConnection) As DataTable
        ''
        LST_status.Items.Add(query)
        ''
        Dim table As New DataTable
        Try
            dtacon.Open()
            dtacmd = New OleDbCommand(query, dtacon)
            dtadap = New OleDbDataAdapter(dtacmd)
            dtadap.Fill(table)
            dtacmd.Dispose()
            dtadap.Dispose()
            dtacon.Close()
        Catch ex As Exception
            dtacon.Close()
            MsgBox("Problemas en la consulta: " + ex.Message(), MsgBoxStyle.Critical)
        End Try
        Return table

    End Function





    Private Sub BTN_StudentDetail_SignOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentDetail_SignOut.Click
        Student_SignOut()
    End Sub

    Sub Student_SignOut()

        StudentIndex = -1
        'TAB_StudentSelelect_Zero()
        TXT_StudentSelect_StudentUserName.Text = ""
        TXT_StudentSelect_StudentPassWord.Text = ""

        'TAB_StudentDetail_Zero
        TXT_StudentDetail_StudentUserName.Text = ""
        TXT_StudentDetail_StudentPassWord.Text = ""
        TAB_StudentDetail.Enabled = False

        'TAB_StudentDegree_Zero()
        LST_StudentDegree.Items.Clear()
        CMB_StudentDegreeList.Items.Clear()
        TAB_StudentDegree.Enabled = False

        'TAB_Enrollment_Zero()
        LST_Decision.Items.Clear()

        TAB_Enrollment.Visible = False

        'TAB_Courses_Zero()
        LST_CoursesRequiredList.Items.Clear()
        TXT_CoursesRequiredName.Text = ""
        LST_CoursesRequiredRequisites.Items.Clear()

        LST_CoursesPossibleList.Items.Clear()
        TXT_CoursesPossibleName.Text = ""
        TXT_CoursesPossibleTermYear.Text = ""
        TXT_CoursesPossibleTermPart.Text = ""

        LST_CoursesCompleteList.Items.Clear()
        TXT_CourseCompleteName.Text = ""
        TXT_done_selected_termyear.Text = ""
        TXT_CourseCompleteTermPart.Text = ""

        TAB_Courses.Visible = False

        TAB_Student.SelectedIndex = 0



    End Sub

End Class
