Imports System
Imports System.Data.OleDb
Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private MyNameIs As String = ""

    Private DataProvider As String = " Provider=Microsoft.Jet.OLEDB.4.0;"
    Private DataSource As String = " Data Source=" & Directory.GetCurrentDirectory() & "\..\" & "dta\LongView.mdb;"
    Private DataUserName As String = " User Id=admin;"
    Private DataPassWord As String = " Password=;"
    Private ConnString As String = DataProvider & DataSource & DataUserName & DataPassWord

    Private dtadap As OleDbDataAdapter
    Private dtatbl As DataTable = New DataTable
    Private dtarow As DataRow

    Private dtacon As New OleDbConnection(ConnString)
    Private dtacmd As OleDbCommand = Nothing
    Private dtardr As OleDbDataReader = Nothing


    'Declare Variables
    'Queries
    Private QRY As String = ""

    ' Student
    Private StudentIndex As Integer = -1
    Private StudentUserName As String = ""
    Private StudentPassWord As String = ""
    Private StudentEnrollmentStep As Integer = 0
    Private StudentMajorIndex As Integer = 0
    Private StudentHoursEarned As Integer = 0

    '    Private CourseRequiredSelectedValue As String
    '    Private CoursePossibleSelectedValue As String
    '    Private CourseCompleteSelectedValue As String

    Private EnrollmentStepIndex = 0

    Dim QRY_Student_Find As String
    Dim ANS_Student_Find As DataTable

    ' Student Tab
    Dim QRY_StudentWelcome_Load As String
    Dim ANS_StudentWelcome_Load As DataTable

    Dim QRY_StudentWelcome_Save As String
    Dim ANS_StudentWelcome_Save As DataTable

    Dim QRY_StudentAccount_Load As String
    Dim ANS_StudentAccount_Load As DataTable

    Dim QRY_StudentMajorIndex_Find As String
    Dim ANS_StudentMajorIndex_Find As DataTable

    Dim QRY_StudentAccount_Save As String
    Dim ANS_StudentAccount_Save As DataTable

    Dim QRY_StudentDegreesItem_Load As String
    Dim ANS_StudentDegreesItem_Load As DataTable

    Dim QRY_StudentDegreesList_Load As String
    Dim ANS_StudentDegreesList_Load As DataTable

    Dim QRY_StudentDegreesItem_Save As String
    Dim ANS_StudentDegreesItem_Save As DataTable

    'Course Tab
    ' Course Required
    Dim QRY_CourseRequiredList_Find As String
    Dim ANS_CourseRequiredList_Find As DataTable
    Dim LST_CourseRequiredList_Find As String

    Dim QRY_CourseRequiredList_Load As String
    Dim ANS_CourseRequiredList_Load As DataTable
    Dim LST_CourseRequiredList_Load As String

    Dim QRY_CourseRequiredItem_Load As String
    Dim ANS_CourseRequiredItem_Load As DataTable

    'Course Possible
    Dim QRY_CoursePossibleList_Find As String
    Dim ANS_CoursePossibleList_Find As DataTable
    Dim LST_CoursePossibeList_Find As String


    Dim QRY_CoursePossibleList_Load As String
    Dim ANS_CoursePossibleList_Load As DataTable
    Dim LST_CoursePossibleList_Load As String
    Dim LST_CoursePossibleList_Find As String

    Dim QRY_CoursePossibleItem_Load As String
    Dim ANS_CoursePossibleItem_Load As DataTable


    Dim QRY_CourseCompleteList_Find As String
    Dim ANS_CourseCompleteList_Find As DataTable
    Dim LST_CourseCompleteList_Find As String

    Dim QRY_CourseCompleteList_Load As String
    Dim ANS_CourseCompleteList_Load As DataTable
    Dim LST_CourseCompleteList_Load As String

    Dim QRY_CourseCompleteItem_Load As String
    Dim ANS_CourseCompleteItem_Load As DataTable

    'Enrollment Step
    Dim QRY_EnrollmentStepAbove_Load As String
    Dim ANS_EnrollmentStepAbove_Load As DataTable

    Dim QRY_EnrollmentStepTween_Load As String
    Dim ANS_EnrollmentStepTween_Load As DataTable

    Dim QRY_EnrollmentStepBelow_Load As String
    Dim ANS_EnrollmentStepBelow_Load As DataTable

    'Dim QRY_CourseIndex_Find As String
    'Dim ANS_CourseIndex_Find As DataTable


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents LST_status As System.Windows.Forms.ListBox
    Friend WithEvents LST_Decision As System.Windows.Forms.ListView
    Friend WithEvents BTN_About_Update As System.Windows.Forms.Button
    Friend WithEvents TAB_Student As System.Windows.Forms.TabControl
    Friend WithEvents BTN_DecisionHead As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionRise As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionTail As System.Windows.Forms.Button
    Friend WithEvents BTN_DecisionFall As System.Windows.Forms.Button
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TAB_Enrollment As System.Windows.Forms.TabControl
    Friend WithEvents LST_Enrollment As System.Windows.Forms.TabPage
    Friend WithEvents TAB_StudentAccount As System.Windows.Forms.TabPage
    Friend WithEvents TAB_StudentWelcome As System.Windows.Forms.TabPage
    Friend WithEvents TXT_StudentWelcome_StudentPassWord As System.Windows.Forms.TextBox
    Friend WithEvents TXT_StudentWelcome_StudentUserName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_StudentWelcome_StudentPassWord As System.Windows.Forms.Label
    Friend WithEvents LBL_StudentWelcome_StudentUserName As System.Windows.Forms.Label
    Friend WithEvents BTN_StudentWelcome_SignOn As System.Windows.Forms.Button
    Friend WithEvents BTN_StudentWelcome_SignUp As System.Windows.Forms.Button
    Friend WithEvents BTN_StudentAccount_Save As System.Windows.Forms.Button
    Friend WithEvents TXT_StudentAccount_StudentPassWord As System.Windows.Forms.TextBox
    Friend WithEvents TXT_StudentAccount_StudentUserName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_StudentAccount_StudentPassWord As System.Windows.Forms.Label
    Friend WithEvents LBL_StudentAccount_StudentUserName As System.Windows.Forms.Label
    Friend WithEvents BTN_StudentAccount_SignOut As System.Windows.Forms.Button
    Friend WithEvents TAB_StudentDegrees As System.Windows.Forms.TabPage
    Friend WithEvents BTN_StudentDegrees_Save As System.Windows.Forms.Button
    Friend WithEvents CMB_StudentDegreesList As System.Windows.Forms.ComboBox
    Friend WithEvents LST_StudentDegrees As System.Windows.Forms.ListBox
    Friend WithEvents LBL_StudentDegrees As System.Windows.Forms.Label
    Friend WithEvents TAB_CourseRequired As System.Windows.Forms.TabPage
    Friend WithEvents TAB_CoursePossible As System.Windows.Forms.TabPage
    Friend WithEvents TAB_CourseComplete As System.Windows.Forms.TabPage
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CourseRequiredRequisites As System.Windows.Forms.Label
    Friend WithEvents LST_CourseRequiredList As System.Windows.Forms.ListBox
    Friend WithEvents LBL_CourseRequiredName As System.Windows.Forms.Label
    Friend WithEvents TXT_CourseRequiredName As System.Windows.Forms.TextBox
    Friend WithEvents LST_CoursePossibleList As System.Windows.Forms.ListBox
    Friend WithEvents TXT_CoursePossibleTermPart As System.Windows.Forms.TextBox
    Friend WithEvents TXT_CoursePossibleTermYear As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CoursePossibleTermYear As System.Windows.Forms.Label
    Friend WithEvents TXT_CoursePossibleName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CoursePossibleName As System.Windows.Forms.Label
    Friend WithEvents BTN_CoursePossible_Save As System.Windows.Forms.Button
    Friend WithEvents LST_CourseCompleteList As System.Windows.Forms.ListBox
    Friend WithEvents TXT_CourseCompleteTermPart As System.Windows.Forms.TextBox
    Friend WithEvents TXT_CourseCompleteTermYear As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CourseCompleteName As System.Windows.Forms.Label
    Friend WithEvents TXT_CourseCompleteName As System.Windows.Forms.TextBox
    Friend WithEvents LBL_CourseCompleteTermYear As System.Windows.Forms.Label
    Friend WithEvents LST_CourseRequiredRequisites As System.Windows.Forms.ListBox
    Friend WithEvents LBL_CoursePossibleTermPart As System.Windows.Forms.Label
    Friend WithEvents LBL_CourseCompleteTermPart As System.Windows.Forms.Label
    Friend WithEvents TAB_Course As System.Windows.Forms.TabControl
    Friend WithEvents LBL_CourseRequiredList As System.Windows.Forms.Label
    Friend WithEvents LBL_CoursePossibleList As System.Windows.Forms.Label
    Friend WithEvents LBL_CourseCompleteList As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.LBL_CourseRequiredRequisites = New System.Windows.Forms.Label
        Me.LST_CourseRequiredList = New System.Windows.Forms.ListBox
        Me.LBL_CourseRequiredName = New System.Windows.Forms.Label
        Me.TXT_CourseRequiredName = New System.Windows.Forms.TextBox
        Me.LST_CoursePossibleList = New System.Windows.Forms.ListBox
        Me.TXT_CoursePossibleTermPart = New System.Windows.Forms.TextBox
        Me.TXT_CoursePossibleTermYear = New System.Windows.Forms.TextBox
        Me.LBL_CoursePossibleTermYear = New System.Windows.Forms.Label
        Me.TXT_CoursePossibleName = New System.Windows.Forms.TextBox
        Me.LBL_CoursePossibleName = New System.Windows.Forms.Label
        Me.BTN_CoursePossible_Save = New System.Windows.Forms.Button
        Me.LST_CourseCompleteList = New System.Windows.Forms.ListBox
        Me.TXT_CourseCompleteTermPart = New System.Windows.Forms.TextBox
        Me.TXT_CourseCompleteTermYear = New System.Windows.Forms.TextBox
        Me.LBL_CourseCompleteName = New System.Windows.Forms.Label
        Me.TXT_CourseCompleteName = New System.Windows.Forms.TextBox
        Me.LBL_CourseCompleteTermYear = New System.Windows.Forms.Label
        Me.LST_CourseRequiredRequisites = New System.Windows.Forms.ListBox
        Me.LBL_CoursePossibleTermPart = New System.Windows.Forms.Label
        Me.LBL_CourseCompleteTermPart = New System.Windows.Forms.Label
        Me.TAB_Course = New System.Windows.Forms.TabControl
        Me.TAB_CourseRequired = New System.Windows.Forms.TabPage
        Me.LBL_CourseRequiredList = New System.Windows.Forms.Label
        Me.TAB_CoursePossible = New System.Windows.Forms.TabPage
        Me.LBL_CoursePossibleList = New System.Windows.Forms.Label
        Me.TAB_CourseComplete = New System.Windows.Forms.TabPage
        Me.LBL_CourseCompleteList = New System.Windows.Forms.Label
        Me.LST_status = New System.Windows.Forms.ListBox
        Me.TAB_Student = New System.Windows.Forms.TabControl
        Me.TAB_StudentWelcome = New System.Windows.Forms.TabPage
        Me.TXT_StudentWelcome_StudentPassWord = New System.Windows.Forms.TextBox
        Me.TXT_StudentWelcome_StudentUserName = New System.Windows.Forms.TextBox
        Me.LBL_StudentWelcome_StudentPassWord = New System.Windows.Forms.Label
        Me.LBL_StudentWelcome_StudentUserName = New System.Windows.Forms.Label
        Me.BTN_StudentWelcome_SignOn = New System.Windows.Forms.Button
        Me.BTN_StudentWelcome_SignUp = New System.Windows.Forms.Button
        Me.TAB_StudentAccount = New System.Windows.Forms.TabPage
        Me.BTN_StudentAccount_Save = New System.Windows.Forms.Button
        Me.TXT_StudentAccount_StudentPassWord = New System.Windows.Forms.TextBox
        Me.TXT_StudentAccount_StudentUserName = New System.Windows.Forms.TextBox
        Me.BTN_About_Update = New System.Windows.Forms.Button
        Me.LBL_StudentAccount_StudentPassWord = New System.Windows.Forms.Label
        Me.LBL_StudentAccount_StudentUserName = New System.Windows.Forms.Label
        Me.BTN_StudentAccount_SignOut = New System.Windows.Forms.Button
        Me.TAB_StudentDegrees = New System.Windows.Forms.TabPage
        Me.LST_StudentDegrees = New System.Windows.Forms.ListBox
        Me.BTN_StudentDegrees_Save = New System.Windows.Forms.Button
        Me.CMB_StudentDegreesList = New System.Windows.Forms.ComboBox
        Me.LBL_StudentDegrees = New System.Windows.Forms.Label
        Me.LST_Decision = New System.Windows.Forms.ListView
        Me.BTN_DecisionHead = New System.Windows.Forms.Button
        Me.BTN_DecisionRise = New System.Windows.Forms.Button
        Me.BTN_DecisionTail = New System.Windows.Forms.Button
        Me.BTN_DecisionFall = New System.Windows.Forms.Button
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TAB_Enrollment = New System.Windows.Forms.TabControl
        Me.LST_Enrollment = New System.Windows.Forms.TabPage
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TAB_Course.SuspendLayout()
        Me.TAB_CourseRequired.SuspendLayout()
        Me.TAB_CoursePossible.SuspendLayout()
        Me.TAB_CourseComplete.SuspendLayout()
        Me.TAB_Student.SuspendLayout()
        Me.TAB_StudentWelcome.SuspendLayout()
        Me.TAB_StudentAccount.SuspendLayout()
        Me.TAB_StudentDegrees.SuspendLayout()
        Me.TAB_Enrollment.SuspendLayout()
        Me.LST_Enrollment.SuspendLayout()
        Me.SuspendLayout()
        '
        'LBL_CourseRequiredRequisites
        '
        Me.LBL_CourseRequiredRequisites.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CourseRequiredRequisites.Name = "LBL_CourseRequiredRequisites"
        Me.LBL_CourseRequiredRequisites.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseRequiredRequisites.TabIndex = 4
        Me.LBL_CourseRequiredRequisites.Text = "Course Requirement(s)"
        Me.LBL_CourseRequiredRequisites.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LBL_CourseRequiredRequisites.Visible = False
        '
        'LST_CourseRequiredList
        '
        Me.LST_CourseRequiredList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CourseRequiredList.Name = "LST_CourseRequiredList"
        Me.LST_CourseRequiredList.Size = New System.Drawing.Size(128, 147)
        Me.LST_CourseRequiredList.TabIndex = 0
        '
        'LBL_CourseRequiredName
        '
        Me.LBL_CourseRequiredName.Location = New System.Drawing.Point(144, 16)
        Me.LBL_CourseRequiredName.Name = "LBL_CourseRequiredName"
        Me.LBL_CourseRequiredName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseRequiredName.TabIndex = 2
        Me.LBL_CourseRequiredName.Text = "Selected Course"
        Me.LBL_CourseRequiredName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CourseRequiredName
        '
        Me.TXT_CourseRequiredName.Enabled = False
        Me.TXT_CourseRequiredName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CourseRequiredName.Multiline = True
        Me.TXT_CourseRequiredName.Name = "TXT_CourseRequiredName"
        Me.TXT_CourseRequiredName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CourseRequiredName.TabIndex = 3
        Me.TXT_CourseRequiredName.Text = ""
        '
        'LST_CoursePossibleList
        '
        Me.LST_CoursePossibleList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CoursePossibleList.Name = "LST_CoursePossibleList"
        Me.LST_CoursePossibleList.Size = New System.Drawing.Size(128, 173)
        Me.LST_CoursePossibleList.TabIndex = 6
        '
        'TXT_CoursePossibleTermPart
        '
        Me.TXT_CoursePossibleTermPart.Location = New System.Drawing.Point(144, 160)
        Me.TXT_CoursePossibleTermPart.Name = "TXT_CoursePossibleTermPart"
        Me.TXT_CoursePossibleTermPart.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CoursePossibleTermPart.TabIndex = 5
        Me.TXT_CoursePossibleTermPart.Text = ""
        '
        'TXT_CoursePossibleTermYear
        '
        Me.TXT_CoursePossibleTermYear.Location = New System.Drawing.Point(144, 104)
        Me.TXT_CoursePossibleTermYear.Name = "TXT_CoursePossibleTermYear"
        Me.TXT_CoursePossibleTermYear.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CoursePossibleTermYear.TabIndex = 4
        Me.TXT_CoursePossibleTermYear.Text = ""
        '
        'LBL_CoursePossibleTermYear
        '
        Me.LBL_CoursePossibleTermYear.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CoursePossibleTermYear.Name = "LBL_CoursePossibleTermYear"
        Me.LBL_CoursePossibleTermYear.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursePossibleTermYear.TabIndex = 3
        Me.LBL_CoursePossibleTermYear.Text = "Year Enrolled"
        Me.LBL_CoursePossibleTermYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CoursePossibleName
        '
        Me.TXT_CoursePossibleName.Enabled = False
        Me.TXT_CoursePossibleName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CoursePossibleName.Multiline = True
        Me.TXT_CoursePossibleName.Name = "TXT_CoursePossibleName"
        Me.TXT_CoursePossibleName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CoursePossibleName.TabIndex = 2
        Me.TXT_CoursePossibleName.Text = ""
        '
        'LBL_CoursePossibleName
        '
        Me.LBL_CoursePossibleName.Location = New System.Drawing.Point(144, 16)
        Me.LBL_CoursePossibleName.Name = "LBL_CoursePossibleName"
        Me.LBL_CoursePossibleName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursePossibleName.TabIndex = 1
        Me.LBL_CoursePossibleName.Text = "Selected Course"
        Me.LBL_CoursePossibleName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_CoursePossible_Save
        '
        Me.BTN_CoursePossible_Save.Location = New System.Drawing.Point(144, 192)
        Me.BTN_CoursePossible_Save.Name = "BTN_CoursePossible_Save"
        Me.BTN_CoursePossible_Save.Size = New System.Drawing.Size(128, 23)
        Me.BTN_CoursePossible_Save.TabIndex = 1
        Me.BTN_CoursePossible_Save.Text = "Save Changes"
        '
        'LST_CourseCompleteList
        '
        Me.LST_CourseCompleteList.Location = New System.Drawing.Point(8, 40)
        Me.LST_CourseCompleteList.Name = "LST_CourseCompleteList"
        Me.LST_CourseCompleteList.Size = New System.Drawing.Size(128, 160)
        Me.LST_CourseCompleteList.TabIndex = 6
        '
        'TXT_CourseCompleteTermPart
        '
        Me.TXT_CourseCompleteTermPart.Enabled = False
        Me.TXT_CourseCompleteTermPart.Location = New System.Drawing.Point(144, 160)
        Me.TXT_CourseCompleteTermPart.Name = "TXT_CourseCompleteTermPart"
        Me.TXT_CourseCompleteTermPart.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CourseCompleteTermPart.TabIndex = 5
        Me.TXT_CourseCompleteTermPart.Text = ""
        '
        'TXT_CourseCompleteTermYear
        '
        Me.TXT_CourseCompleteTermYear.Enabled = False
        Me.TXT_CourseCompleteTermYear.Location = New System.Drawing.Point(144, 104)
        Me.TXT_CourseCompleteTermYear.Name = "TXT_CourseCompleteTermYear"
        Me.TXT_CourseCompleteTermYear.Size = New System.Drawing.Size(128, 20)
        Me.TXT_CourseCompleteTermYear.TabIndex = 4
        Me.TXT_CourseCompleteTermYear.Text = ""
        '
        'LBL_CourseCompleteName
        '
        Me.LBL_CourseCompleteName.Location = New System.Drawing.Point(152, 16)
        Me.LBL_CourseCompleteName.Name = "LBL_CourseCompleteName"
        Me.LBL_CourseCompleteName.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteName.TabIndex = 1
        Me.LBL_CourseCompleteName.Text = "Selected Course"
        Me.LBL_CourseCompleteName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TXT_CourseCompleteName
        '
        Me.TXT_CourseCompleteName.Enabled = False
        Me.TXT_CourseCompleteName.Location = New System.Drawing.Point(144, 40)
        Me.TXT_CourseCompleteName.Multiline = True
        Me.TXT_CourseCompleteName.Name = "TXT_CourseCompleteName"
        Me.TXT_CourseCompleteName.Size = New System.Drawing.Size(128, 32)
        Me.TXT_CourseCompleteName.TabIndex = 2
        Me.TXT_CourseCompleteName.Text = ""
        '
        'LBL_CourseCompleteTermYear
        '
        Me.LBL_CourseCompleteTermYear.Location = New System.Drawing.Point(144, 80)
        Me.LBL_CourseCompleteTermYear.Name = "LBL_CourseCompleteTermYear"
        Me.LBL_CourseCompleteTermYear.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteTermYear.TabIndex = 3
        Me.LBL_CourseCompleteTermYear.Text = "Year Enrolled"
        Me.LBL_CourseCompleteTermYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_CourseRequiredRequisites
        '
        Me.LST_CourseRequiredRequisites.Enabled = False
        Me.LST_CourseRequiredRequisites.Location = New System.Drawing.Point(144, 112)
        Me.LST_CourseRequiredRequisites.Name = "LST_CourseRequiredRequisites"
        Me.LST_CourseRequiredRequisites.Size = New System.Drawing.Size(128, 69)
        Me.LST_CourseRequiredRequisites.TabIndex = 11
        Me.LST_CourseRequiredRequisites.Visible = False
        '
        'LBL_CoursePossibleTermPart
        '
        Me.LBL_CoursePossibleTermPart.Location = New System.Drawing.Point(144, 136)
        Me.LBL_CoursePossibleTermPart.Name = "LBL_CoursePossibleTermPart"
        Me.LBL_CoursePossibleTermPart.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursePossibleTermPart.TabIndex = 12
        Me.LBL_CoursePossibleTermPart.Text = "Term Enrolled"
        Me.LBL_CoursePossibleTermPart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_CourseCompleteTermPart
        '
        Me.LBL_CourseCompleteTermPart.Location = New System.Drawing.Point(144, 136)
        Me.LBL_CourseCompleteTermPart.Name = "LBL_CourseCompleteTermPart"
        Me.LBL_CourseCompleteTermPart.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteTermPart.TabIndex = 13
        Me.LBL_CourseCompleteTermPart.Text = "Term Enrolled"
        Me.LBL_CourseCompleteTermPart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_Course
        '
        Me.TAB_Course.Controls.Add(Me.TAB_CourseRequired)
        Me.TAB_Course.Controls.Add(Me.TAB_CoursePossible)
        Me.TAB_Course.Controls.Add(Me.TAB_CourseComplete)
        Me.TAB_Course.Location = New System.Drawing.Point(536, 16)
        Me.TAB_Course.Multiline = True
        Me.TAB_Course.Name = "TAB_Course"
        Me.TAB_Course.SelectedIndex = 0
        Me.TAB_Course.Size = New System.Drawing.Size(312, 280)
        Me.TAB_Course.TabIndex = 14
        '
        'TAB_CourseRequired
        '
        Me.TAB_CourseRequired.Controls.Add(Me.LBL_CourseRequiredList)
        Me.TAB_CourseRequired.Controls.Add(Me.LST_CourseRequiredList)
        Me.TAB_CourseRequired.Controls.Add(Me.LBL_CourseRequiredName)
        Me.TAB_CourseRequired.Controls.Add(Me.TXT_CourseRequiredName)
        Me.TAB_CourseRequired.Controls.Add(Me.LBL_CourseRequiredRequisites)
        Me.TAB_CourseRequired.Controls.Add(Me.LST_CourseRequiredRequisites)
        Me.TAB_CourseRequired.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CourseRequired.Name = "TAB_CourseRequired"
        Me.TAB_CourseRequired.Size = New System.Drawing.Size(304, 254)
        Me.TAB_CourseRequired.TabIndex = 0
        Me.TAB_CourseRequired.Text = "Courses Required"
        '
        'LBL_CourseRequiredList
        '
        Me.LBL_CourseRequiredList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CourseRequiredList.Name = "LBL_CourseRequiredList"
        Me.LBL_CourseRequiredList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseRequiredList.TabIndex = 0
        Me.LBL_CourseRequiredList.Text = "Required Courses"
        Me.LBL_CourseRequiredList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_CoursePossible
        '
        Me.TAB_CoursePossible.Controls.Add(Me.LBL_CoursePossibleList)
        Me.TAB_CoursePossible.Controls.Add(Me.LST_CoursePossibleList)
        Me.TAB_CoursePossible.Controls.Add(Me.LBL_CoursePossibleTermPart)
        Me.TAB_CoursePossible.Controls.Add(Me.TXT_CoursePossibleTermPart)
        Me.TAB_CoursePossible.Controls.Add(Me.TXT_CoursePossibleTermYear)
        Me.TAB_CoursePossible.Controls.Add(Me.LBL_CoursePossibleTermYear)
        Me.TAB_CoursePossible.Controls.Add(Me.TXT_CoursePossibleName)
        Me.TAB_CoursePossible.Controls.Add(Me.LBL_CoursePossibleName)
        Me.TAB_CoursePossible.Controls.Add(Me.BTN_CoursePossible_Save)
        Me.TAB_CoursePossible.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CoursePossible.Name = "TAB_CoursePossible"
        Me.TAB_CoursePossible.Size = New System.Drawing.Size(304, 254)
        Me.TAB_CoursePossible.TabIndex = 1
        Me.TAB_CoursePossible.Text = "Courses Possible"
        '
        'LBL_CoursePossibleList
        '
        Me.LBL_CoursePossibleList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CoursePossibleList.Name = "LBL_CoursePossibleList"
        Me.LBL_CoursePossibleList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CoursePossibleList.TabIndex = 13
        Me.LBL_CoursePossibleList.Text = "Possible Courses"
        Me.LBL_CoursePossibleList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TAB_CourseComplete
        '
        Me.TAB_CourseComplete.Controls.Add(Me.LBL_CourseCompleteList)
        Me.TAB_CourseComplete.Controls.Add(Me.TXT_CourseCompleteTermPart)
        Me.TAB_CourseComplete.Controls.Add(Me.TXT_CourseCompleteTermYear)
        Me.TAB_CourseComplete.Controls.Add(Me.LBL_CourseCompleteName)
        Me.TAB_CourseComplete.Controls.Add(Me.TXT_CourseCompleteName)
        Me.TAB_CourseComplete.Controls.Add(Me.LBL_CourseCompleteTermYear)
        Me.TAB_CourseComplete.Controls.Add(Me.LBL_CourseCompleteTermPart)
        Me.TAB_CourseComplete.Controls.Add(Me.LST_CourseCompleteList)
        Me.TAB_CourseComplete.Location = New System.Drawing.Point(4, 22)
        Me.TAB_CourseComplete.Name = "TAB_CourseComplete"
        Me.TAB_CourseComplete.Size = New System.Drawing.Size(304, 254)
        Me.TAB_CourseComplete.TabIndex = 2
        Me.TAB_CourseComplete.Text = "Courses Complete"
        '
        'LBL_CourseCompleteList
        '
        Me.LBL_CourseCompleteList.Location = New System.Drawing.Point(16, 16)
        Me.LBL_CourseCompleteList.Name = "LBL_CourseCompleteList"
        Me.LBL_CourseCompleteList.Size = New System.Drawing.Size(128, 16)
        Me.LBL_CourseCompleteList.TabIndex = 14
        Me.LBL_CourseCompleteList.Text = "Complete Courses"
        Me.LBL_CourseCompleteList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_status
        '
        Me.LST_status.Location = New System.Drawing.Point(8, 320)
        Me.LST_status.Name = "LST_status"
        Me.LST_status.ScrollAlwaysVisible = True
        Me.LST_status.Size = New System.Drawing.Size(1312, 95)
        Me.LST_status.TabIndex = 15
        '
        'TAB_Student
        '
        Me.TAB_Student.Controls.Add(Me.TAB_StudentWelcome)
        Me.TAB_Student.Controls.Add(Me.TAB_StudentAccount)
        Me.TAB_Student.Controls.Add(Me.TAB_StudentDegrees)
        Me.TAB_Student.Location = New System.Drawing.Point(8, 16)
        Me.TAB_Student.Multiline = True
        Me.TAB_Student.Name = "TAB_Student"
        Me.TAB_Student.SelectedIndex = 0
        Me.TAB_Student.Size = New System.Drawing.Size(312, 216)
        Me.TAB_Student.TabIndex = 16
        '
        'TAB_StudentWelcome
        '
        Me.TAB_StudentWelcome.Controls.Add(Me.TXT_StudentWelcome_StudentPassWord)
        Me.TAB_StudentWelcome.Controls.Add(Me.TXT_StudentWelcome_StudentUserName)
        Me.TAB_StudentWelcome.Controls.Add(Me.LBL_StudentWelcome_StudentPassWord)
        Me.TAB_StudentWelcome.Controls.Add(Me.LBL_StudentWelcome_StudentUserName)
        Me.TAB_StudentWelcome.Controls.Add(Me.BTN_StudentWelcome_SignOn)
        Me.TAB_StudentWelcome.Controls.Add(Me.BTN_StudentWelcome_SignUp)
        Me.TAB_StudentWelcome.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentWelcome.Name = "TAB_StudentWelcome"
        Me.TAB_StudentWelcome.Size = New System.Drawing.Size(304, 190)
        Me.TAB_StudentWelcome.TabIndex = 0
        Me.TAB_StudentWelcome.Text = "Student Welcome"
        '
        'TXT_StudentWelcome_StudentPassWord
        '
        Me.TXT_StudentWelcome_StudentPassWord.Location = New System.Drawing.Point(16, 120)
        Me.TXT_StudentWelcome_StudentPassWord.Multiline = True
        Me.TXT_StudentWelcome_StudentPassWord.Name = "TXT_StudentWelcome_StudentPassWord"
        Me.TXT_StudentWelcome_StudentPassWord.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.TXT_StudentWelcome_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.TXT_StudentWelcome_StudentPassWord.TabIndex = 5
        Me.TXT_StudentWelcome_StudentPassWord.Text = ""
        '
        'TXT_StudentWelcome_StudentUserName
        '
        Me.TXT_StudentWelcome_StudentUserName.Location = New System.Drawing.Point(16, 48)
        Me.TXT_StudentWelcome_StudentUserName.Multiline = True
        Me.TXT_StudentWelcome_StudentUserName.Name = "TXT_StudentWelcome_StudentUserName"
        Me.TXT_StudentWelcome_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.TXT_StudentWelcome_StudentUserName.TabIndex = 4
        Me.TXT_StudentWelcome_StudentUserName.Text = ""
        '
        'LBL_StudentWelcome_StudentPassWord
        '
        Me.LBL_StudentWelcome_StudentPassWord.Location = New System.Drawing.Point(8, 88)
        Me.LBL_StudentWelcome_StudentPassWord.Name = "LBL_StudentWelcome_StudentPassWord"
        Me.LBL_StudentWelcome_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentWelcome_StudentPassWord.TabIndex = 3
        Me.LBL_StudentWelcome_StudentPassWord.Text = "Password"
        Me.LBL_StudentWelcome_StudentPassWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_StudentWelcome_StudentUserName
        '
        Me.LBL_StudentWelcome_StudentUserName.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentWelcome_StudentUserName.Name = "LBL_StudentWelcome_StudentUserName"
        Me.LBL_StudentWelcome_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentWelcome_StudentUserName.TabIndex = 2
        Me.LBL_StudentWelcome_StudentUserName.Text = "Username"
        Me.LBL_StudentWelcome_StudentUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_StudentWelcome_SignOn
        '
        Me.BTN_StudentWelcome_SignOn.Location = New System.Drawing.Point(160, 152)
        Me.BTN_StudentWelcome_SignOn.Name = "BTN_StudentWelcome_SignOn"
        Me.BTN_StudentWelcome_SignOn.TabIndex = 1
        Me.BTN_StudentWelcome_SignOn.Text = "Sign On"
        '
        'BTN_StudentWelcome_SignUp
        '
        Me.BTN_StudentWelcome_SignUp.Location = New System.Drawing.Point(16, 152)
        Me.BTN_StudentWelcome_SignUp.Name = "BTN_StudentWelcome_SignUp"
        Me.BTN_StudentWelcome_SignUp.TabIndex = 0
        Me.BTN_StudentWelcome_SignUp.Text = "Sign Up"
        '
        'TAB_StudentAccount
        '
        Me.TAB_StudentAccount.Controls.Add(Me.BTN_StudentAccount_Save)
        Me.TAB_StudentAccount.Controls.Add(Me.TXT_StudentAccount_StudentPassWord)
        Me.TAB_StudentAccount.Controls.Add(Me.TXT_StudentAccount_StudentUserName)
        Me.TAB_StudentAccount.Controls.Add(Me.BTN_About_Update)
        Me.TAB_StudentAccount.Controls.Add(Me.LBL_StudentAccount_StudentPassWord)
        Me.TAB_StudentAccount.Controls.Add(Me.LBL_StudentAccount_StudentUserName)
        Me.TAB_StudentAccount.Controls.Add(Me.BTN_StudentAccount_SignOut)
        Me.TAB_StudentAccount.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentAccount.Name = "TAB_StudentAccount"
        Me.TAB_StudentAccount.Size = New System.Drawing.Size(304, 190)
        Me.TAB_StudentAccount.TabIndex = 1
        Me.TAB_StudentAccount.Text = "Student Account"
        '
        'BTN_StudentAccount_Save
        '
        Me.BTN_StudentAccount_Save.Location = New System.Drawing.Point(160, 160)
        Me.BTN_StudentAccount_Save.Name = "BTN_StudentAccount_Save"
        Me.BTN_StudentAccount_Save.TabIndex = 28
        Me.BTN_StudentAccount_Save.Text = "Save"
        '
        'TXT_StudentAccount_StudentPassWord
        '
        Me.TXT_StudentAccount_StudentPassWord.Location = New System.Drawing.Point(16, 120)
        Me.TXT_StudentAccount_StudentPassWord.Name = "TXT_StudentAccount_StudentPassWord"
        Me.TXT_StudentAccount_StudentPassWord.Size = New System.Drawing.Size(218, 20)
        Me.TXT_StudentAccount_StudentPassWord.TabIndex = 11
        Me.TXT_StudentAccount_StudentPassWord.Text = "TextBox1"
        '
        'TXT_StudentAccount_StudentUserName
        '
        Me.TXT_StudentAccount_StudentUserName.Location = New System.Drawing.Point(16, 48)
        Me.TXT_StudentAccount_StudentUserName.Name = "TXT_StudentAccount_StudentUserName"
        Me.TXT_StudentAccount_StudentUserName.Size = New System.Drawing.Size(218, 20)
        Me.TXT_StudentAccount_StudentUserName.TabIndex = 10
        Me.TXT_StudentAccount_StudentUserName.Text = "TextBox1"
        '
        'BTN_About_Update
        '
        Me.BTN_About_Update.Location = New System.Drawing.Point(64, 240)
        Me.BTN_About_Update.Name = "BTN_About_Update"
        Me.BTN_About_Update.TabIndex = 9
        Me.BTN_About_Update.Text = "Update"
        '
        'LBL_StudentAccount_StudentPassWord
        '
        Me.LBL_StudentAccount_StudentPassWord.Location = New System.Drawing.Point(8, 88)
        Me.LBL_StudentAccount_StudentPassWord.Name = "LBL_StudentAccount_StudentPassWord"
        Me.LBL_StudentAccount_StudentPassWord.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentAccount_StudentPassWord.TabIndex = 8
        Me.LBL_StudentAccount_StudentPassWord.Text = "PassWord"
        Me.LBL_StudentAccount_StudentPassWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBL_StudentAccount_StudentUserName
        '
        Me.LBL_StudentAccount_StudentUserName.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentAccount_StudentUserName.Name = "LBL_StudentAccount_StudentUserName"
        Me.LBL_StudentAccount_StudentUserName.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentAccount_StudentUserName.TabIndex = 7
        Me.LBL_StudentAccount_StudentUserName.Text = "UserName"
        Me.LBL_StudentAccount_StudentUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BTN_StudentAccount_SignOut
        '
        Me.BTN_StudentAccount_SignOut.Location = New System.Drawing.Point(16, 160)
        Me.BTN_StudentAccount_SignOut.Name = "BTN_StudentAccount_SignOut"
        Me.BTN_StudentAccount_SignOut.TabIndex = 27
        Me.BTN_StudentAccount_SignOut.Text = "Sign Out"
        '
        'TAB_StudentDegrees
        '
        Me.TAB_StudentDegrees.Controls.Add(Me.LST_StudentDegrees)
        Me.TAB_StudentDegrees.Controls.Add(Me.BTN_StudentDegrees_Save)
        Me.TAB_StudentDegrees.Controls.Add(Me.CMB_StudentDegreesList)
        Me.TAB_StudentDegrees.Controls.Add(Me.LBL_StudentDegrees)
        Me.TAB_StudentDegrees.Location = New System.Drawing.Point(4, 22)
        Me.TAB_StudentDegrees.Name = "TAB_StudentDegrees"
        Me.TAB_StudentDegrees.Size = New System.Drawing.Size(304, 190)
        Me.TAB_StudentDegrees.TabIndex = 2
        Me.TAB_StudentDegrees.Text = "Student Degrees"
        '
        'LST_StudentDegrees
        '
        Me.LST_StudentDegrees.Location = New System.Drawing.Point(16, 48)
        Me.LST_StudentDegrees.Name = "LST_StudentDegrees"
        Me.LST_StudentDegrees.Size = New System.Drawing.Size(216, 56)
        Me.LST_StudentDegrees.TabIndex = 23
        '
        'BTN_StudentDegrees_Save
        '
        Me.BTN_StudentDegrees_Save.Location = New System.Drawing.Point(16, 160)
        Me.BTN_StudentDegrees_Save.Name = "BTN_StudentDegrees_Save"
        Me.BTN_StudentDegrees_Save.Size = New System.Drawing.Size(216, 24)
        Me.BTN_StudentDegrees_Save.TabIndex = 22
        Me.BTN_StudentDegrees_Save.Text = "Add Selected Degree"
        '
        'CMB_StudentDegreesList
        '
        Me.CMB_StudentDegreesList.Location = New System.Drawing.Point(16, 120)
        Me.CMB_StudentDegreesList.Name = "CMB_StudentDegreesList"
        Me.CMB_StudentDegreesList.Size = New System.Drawing.Size(216, 21)
        Me.CMB_StudentDegreesList.TabIndex = 8
        '
        'LBL_StudentDegrees
        '
        Me.LBL_StudentDegrees.Location = New System.Drawing.Point(8, 16)
        Me.LBL_StudentDegrees.Name = "LBL_StudentDegrees"
        Me.LBL_StudentDegrees.Size = New System.Drawing.Size(218, 16)
        Me.LBL_StudentDegrees.TabIndex = 0
        Me.LBL_StudentDegrees.Text = "Degrees"
        Me.LBL_StudentDegrees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST_Decision
        '
        Me.LST_Decision.Location = New System.Drawing.Point(64, 8)
        Me.LST_Decision.Name = "LST_Decision"
        Me.LST_Decision.Size = New System.Drawing.Size(104, 184)
        Me.LST_Decision.TabIndex = 17
        '
        'BTN_DecisionHead
        '
        Me.BTN_DecisionHead.Location = New System.Drawing.Point(8, 8)
        Me.BTN_DecisionHead.Name = "BTN_DecisionHead"
        Me.BTN_DecisionHead.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionHead.TabIndex = 21
        Me.BTN_DecisionHead.Text = "Start"
        '
        'BTN_DecisionRise
        '
        Me.BTN_DecisionRise.Location = New System.Drawing.Point(8, 40)
        Me.BTN_DecisionRise.Name = "BTN_DecisionRise"
        Me.BTN_DecisionRise.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionRise.TabIndex = 22
        Me.BTN_DecisionRise.Text = "Prior"
        '
        'BTN_DecisionTail
        '
        Me.BTN_DecisionTail.Location = New System.Drawing.Point(8, 168)
        Me.BTN_DecisionTail.Name = "BTN_DecisionTail"
        Me.BTN_DecisionTail.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionTail.TabIndex = 23
        Me.BTN_DecisionTail.Text = "Final"
        '
        'BTN_DecisionFall
        '
        Me.BTN_DecisionFall.Location = New System.Drawing.Point(8, 136)
        Me.BTN_DecisionFall.Name = "BTN_DecisionFall"
        Me.BTN_DecisionFall.Size = New System.Drawing.Size(48, 24)
        Me.BTN_DecisionFall.TabIndex = 24
        Me.BTN_DecisionFall.Text = "After"
        '
        'TabPage1
        '
        Me.TabPage1.Location = New System.Drawing.Point(4, 218)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(176, 26)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Decisions"
        '
        'TAB_Enrollment
        '
        Me.TAB_Enrollment.Controls.Add(Me.LST_Enrollment)
        Me.TAB_Enrollment.Location = New System.Drawing.Point(336, 16)
        Me.TAB_Enrollment.Multiline = True
        Me.TAB_Enrollment.Name = "TAB_Enrollment"
        Me.TAB_Enrollment.SelectedIndex = 0
        Me.TAB_Enrollment.Size = New System.Drawing.Size(184, 248)
        Me.TAB_Enrollment.TabIndex = 26
        '
        'LST_Enrollment
        '
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionFall)
        Me.LST_Enrollment.Controls.Add(Me.LST_Decision)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionHead)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionRise)
        Me.LST_Enrollment.Controls.Add(Me.BTN_DecisionTail)
        Me.LST_Enrollment.Location = New System.Drawing.Point(4, 22)
        Me.LST_Enrollment.Name = "LST_Enrollment"
        Me.LST_Enrollment.Size = New System.Drawing.Size(176, 222)
        Me.LST_Enrollment.TabIndex = 0
        Me.LST_Enrollment.Text = "Enrollment"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(16, 448)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(800, 144)
        Me.TextBox1.TabIndex = 27
        Me.TextBox1.Text = "TextBox1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1362, 684)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TAB_Enrollment)
        Me.Controls.Add(Me.TAB_Student)
        Me.Controls.Add(Me.LST_status)
        Me.Controls.Add(Me.TAB_Course)
        Me.MaximumSize = New System.Drawing.Size(2000, 720)
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.Text = "LongView"
        Me.TAB_Course.ResumeLayout(False)
        Me.TAB_CourseRequired.ResumeLayout(False)
        Me.TAB_CoursePossible.ResumeLayout(False)
        Me.TAB_CourseComplete.ResumeLayout(False)
        Me.TAB_Student.ResumeLayout(False)
        Me.TAB_StudentWelcome.ResumeLayout(False)
        Me.TAB_StudentAccount.ResumeLayout(False)
        Me.TAB_StudentDegrees.ResumeLayout(False)
        Me.TAB_Enrollment.ResumeLayout(False)
        Me.LST_Enrollment.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub SayHello(ByVal Greeting As String)
        TextBox1.Text &= Environment.NewLine & " " & Greeting
    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CoreData_Fill()
    End Sub
    Private Sub StudentWelcome_Make()
        'SignUp
        StudentIndex = Student_Find()

        If (StudentIndex > 0) Then
            LST_status.Items.Add("Student Currently Exists. Please Signon Instead")
        Else
            LST_status.Items.Add("Student Does Not Currently Exist. Creating the Student")

            StudentWelcome_Save()
        End If
    End Sub
    Private Sub StudentWelcome_Load()
        ' SignOn

        StudentIndex = Student_Find()

        StudentMajorIndex = StudentMajorIndex_Find()

        If (StudentIndex > 0) Then
            LST_status.Items.Add("Student Currently Exists. Student Is Now Signed On")
        Else
            LST_status.Items.Add("Student Does Not Currently Exist. Please Signup")
        End If

        EnrollmentStep_Load()

        'CourseRequiredList_Find()

    End Sub
    Private Sub StudentWelcome_Save()

        Dim tmpStudentIndex As Integer = -1

        Dim QRY As String = ""
        QRY = QRY_StudentAccount_Save
        QRY = QRY.Replace("{StudentUserName}", TXT_StudentWelcome_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentWelcome_StudentPassWord.Text)

        ANS_StudentAccount_Save = Data_Load(QRY, dtacon)

        StudentIndex = Student_Find()

        If (tmpStudentIndex <> -1) Then
            LST_status.Items.Add("Student Account was successfully created")
        Else
            LST_status.Items.Add("Student Account was Unable to be saved")
        End If

    End Sub
    Private Function Student_Find()

        Dim tmpStudentIndex As Integer = -1

        Dim QRY As String = ""

        QRY = QRY_Student_Find
        QRY = QRY.Replace("{StudentUserName}", TXT_StudentWelcome_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentWelcome_StudentPassWord.Text)

        If Not (IsNothing(ANS_Student_Find)) Then
            ANS_Student_Find.Clear()
        End If

        ANS_Student_Find = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_Student_Find.Rows
            tmpStudentIndex = row.Item("StudentIndex")
        Next row

        Return tmpStudentIndex

    End Function
    Private Function StudentMajorIndex_Find()

        Dim tmpStudentMajorIndex As Integer = -1

        Dim QRY As String = ""

        QRY = QRY_StudentMajorIndex_Find
        QRY = QRY.Replace("{StudentIndex}", StudentIndex)


        ANS_StudentMajorIndex_Find = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_StudentMajorIndex_Find.Rows
            tmpStudentMajorIndex = row.Item("DegreeIndex")
        Next row

        Return tmpStudentMajorIndex

    End Function

    Private Sub BTN_Select_SignUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentWelcome_SignUp.Click
        'done
        StudentWelcome_Make()
    End Sub
    Private Sub BTN_Select_SignOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentWelcome_SignOn.Click
        'done
        StudentWelcome_Load()
    End Sub
    Public Sub TAB_StudentWelcome_Show()
        'done
        TAB_StudentWelcome_Load()
        TAB_StudentWelcome_Fill()
    End Sub
    Public Sub TAB_StudentWelcome_Load()
    End Sub
    Public Sub TAB_StudentWelcome_Fill()

    End Sub
    Public Sub TAB_StudentAccount_Show()
        'done
        TAB_StudentAccount_Load()
    End Sub
    Public Sub TAB_StudentAccount_Load()
        'done
        Dim QRY As String = QRY_StudentAccount_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentAccount_Load = Data_Load(QRY, dtacon)

        For Each row As DataRow In ANS_StudentAccount_Load.Rows
            If IsDBNull(row.Item("StudentUserName")) Then
                StudentUserName = ""
            Else
                StudentUserName = row.Item("StudentUserName")
            End If
        Next row

        TXT_StudentAccount_StudentUserName.Text = StudentUserName
    End Sub
    Public Sub TAB_StudentDegrees_Show()
        'done
        TAB_StudentDegrees_Load()
    End Sub
    Public Sub TAB_StudentDegrees_Load()
        'done
        TAB_StudentDegreesItem_Load()
        TAB_StudentDegreesList_Load()
    End Sub
    Public Sub TAB_StudentDegreesItem_Load()
        Dim QRY As String = QRY_StudentDegreesItem_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentDegreesItem_Load = Data_Load(QRY, dtacon)

        LST_StudentDegrees.Items.Clear()

        For Each row As DataRow In ANS_StudentDegreesItem_Load.Rows
            LST_StudentDegrees.Items.Add(row.Item("MajorTitle"))
        Next row
    End Sub
    Public Sub TAB_StudentDegreesList_Load()
        'done
        Dim QRY As String = QRY_StudentDegreesList_Load

        QRY = QRY.Replace("{StudentIndex}", "StudentIndex")

        ANS_StudentDegreesList_Load = Data_Load(QRY, dtacon)

        CMB_StudentDegreesList.Items.Clear()

        For Each row As DataRow In ANS_StudentDegreesList_Load.Rows
            CMB_StudentDegreesList.Items.Add(row.Item("MajorTitle"))
            CMB_StudentDegreesList.SelectedItem = row.Item("MajorTitle")
        Next row
    End Sub
    Private Sub TAB_Student_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TAB_Student.Click
        'done
        If TAB_Student.SelectedIndex = 0 Then
            TAB_StudentWelcome_Show()
        End If
        If TAB_Student.SelectedIndex = 1 Then
            TAB_StudentAccount_Show()
        End If
        If TAB_Student.SelectedIndex = 2 Then
            TAB_StudentDegrees_Show()
        End If
    End Sub
    Private Sub TAB_Course_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TAB_Course.Click
        'done
        If TAB_Course.SelectedIndex = 0 Then
            TAB_CourseRequiredList_Show()
        End If
        If TAB_Course.SelectedIndex = 1 Then
            TAB_CoursePossibleList_Show()
        End If
        If TAB_Course.SelectedIndex = 2 Then
            TAB_CourseCompleteList_Show()
        End If
    End Sub

    Public Sub TAB_CourseRequiredList_Show()
        TAB_CoursesRequiredList_Load()
    End Sub
    Public Sub TAB_CoursesRequiredList_Load()
        CourseRequiredList_Find()
        CourseRequiredItem_Load()
    End Sub

    Public Sub TAB_CourseCompleteList_Show()
        'done
        'CourseCompleteList_Find()
        TAB_CoursesCompleteList_Load()
    End Sub

    Public Sub TAB_CoursesCompleteList_Load()
        CourseCompleteList_Find()
        CourseCompleteItem_Load()
    End Sub

    Private Sub CourseRequiredItem_Load()
        Dim MyNameIs As String = ""
        SayHello(MyNameIs)
        'done
        Dim QRY As String = QRY_CourseRequiredList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)
        QRY = QRY.Replace("{LST_CourseRequiredList_Find}", LST_CourseRequiredList_Find)

        TextBox1.Text = QRY

        ANS_CourseRequiredList_Load = Data_Load(QRY, dtacon)

        LST_CourseRequiredList.Items.Clear()

        For Each row As DataRow In ANS_CourseRequiredList_Load.Rows
            LST_CourseRequiredList.Items.Add(row.Item("CourseName"))
        Next row

    End Sub

    Private Sub CourseCompleteItem_Load()
        'done
        Dim QRY As String = QRY_CourseCompleteList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)
        QRY = QRY.Replace("{LST_CourseCompleteList_Find}", LST_CourseCompleteList_Find)

        TextBox1.Text = QRY

        ANS_CourseCompleteList_Load = Data_Load(QRY, dtacon)

        LST_CourseCompleteList.Items.Clear()

        For Each row As DataRow In ANS_CourseCompleteList_Load.Rows
            LST_CourseCompleteList.Items.Add(row.Item("CourseName"))
        Next row

    End Sub
    '
    Private Sub CoursePossibleItem_Load()
        'done
        Dim QRY As String = QRY_CoursePossibleList_Load

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)
        QRY = QRY.Replace("{LST_CoursePossibleList_Find}", LST_CoursePossibleList_Find)

        ANS_CoursePossibleList_Load = Data_Load(QRY, dtacon)

        LST_CoursePossibleList.Items.Clear()

        For Each row As DataRow In ANS_CoursePossibleList_Load.Rows
            LST_CoursePossibleList.Items.Add(row.Item("CourseName"))
        Next row

    End Sub
    Public Sub TAB_CoursePossibleList_Show()
        'done
        TAB_CoursePossibleList_Load()
    End Sub
    Public Sub TAB_CoursePossibleList_Load()
        CoursePossibleList_Find()
        CoursePossibleItem_Load()

    End Sub
    Public Sub TAB_CourseCompleteList_Load()
        CourseCompleteList_Find()
        CourseCompleteItem_Load()
    End Sub
    Public Sub EnrollmentStep_Load()
    End Sub
    Public Sub EnrollmentStepAbove_Load()
    End Sub
    Public Sub EnrollmentStepTween_Load()
    End Sub
    Public Sub EnrollmentStepBelow_Load()
    End Sub
    Private Sub StudentAccount_Save()
        Dim QRY As String = QRY_StudentAccount_Save

        QRY = QRY.Replace("{StudentUserName}", TXT_StudentAccount_StudentUserName.Text)
        QRY = QRY.Replace("{StudentPassWord}", TXT_StudentAccount_StudentPassWord.Text)
        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_StudentAccount_Save = Data_Load(QRY, dtacon)
    End Sub
    Private Sub BTN_StudentDegree_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentDegrees_Save.Click
    End Sub
    Private Sub BTN_StudentDetail_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentAccount_Save.Click
        StudentAccount_Save()
    End Sub
    Public Function Data_Load(ByVal query As String, ByVal connection As OleDbConnection) As DataTable
        'done
        Dim table As New DataTable
        Try
            dtacon.Open()
            dtacmd = New OleDbCommand(query, dtacon)
            dtadap = New OleDbDataAdapter(dtacmd)
            dtadap.Fill(table)
            dtacmd.Dispose()
            dtadap.Dispose()
            dtacon.Close()
        Catch ex As Exception
            dtacon.Close()
            MsgBox("Problemas en la consulta: " + ex.Message(), MsgBoxStyle.Critical)
        End Try
        Return table

    End Function
    Private Sub BTN_StudentDetail_SignOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_StudentAccount_SignOut.Click
        Student_SignOut()
    End Sub
    Sub Student_SignOut()
        'half

        StudentIndex = -1
        'TAB_StudentSelelect_Zero()
        TXT_StudentWelcome_StudentUserName.Text = ""
        TXT_StudentWelcome_StudentPassWord.Text = ""

        'TAB_StudentDetail_Zero
        TXT_StudentAccount_StudentUserName.Text = ""
        TXT_StudentAccount_StudentPassWord.Text = ""
        TAB_StudentAccount.Enabled = False

        'TAB_StudentDegree_Zero()
        LST_StudentDegrees.Items.Clear()
        CMB_StudentDegreesList.Items.Clear()
        TAB_StudentDegrees.Enabled = False

        'TAB_Enrollment_Zero()
        LST_Decision.Items.Clear()

        TAB_Enrollment.Visible = False

        'TAB_Courses_Zero()
        LST_CourseRequiredList.Items.Clear()
        TXT_CourseRequiredName.Text = ""
        LST_CourseRequiredRequisites.Items.Clear()

        LST_CoursePossibleList.Items.Clear()
        TXT_CoursePossibleName.Text = ""
        TXT_CoursePossibleTermYear.Text = ""
        TXT_CoursePossibleTermPart.Text = ""

        LST_CourseCompleteList.Items.Clear()
        TXT_CourseCompleteName.Text = ""
        TXT_CourseCompleteTermYear.Text = ""
        TXT_CourseCompleteTermPart.Text = ""

        TAB_Course.Visible = False

        TAB_Student.SelectedIndex = 0
    End Sub
    Private Sub LST_CoursesRequiredList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LST_CourseRequiredList.SelectedIndexChanged
        'half
        'LST_CourseRequiredItem_Load()
        'CourseRequisitesList_Load()
        'load info about selected course
        Dim SelectedItem = LST_CourseRequiredList.SelectedItem

        For Each row As DataRow In ANS_CourseRequiredList_Load.Rows
            If SelectedItem = row.Item("CourseName") Then
                'LST_CourseRequiredList.Items.Add(row.Item("CourseName"))
                TXT_CourseRequiredName.Text = row.Item("CourseTitle")
            End If
        Next row
    End Sub

    Private Sub LST_CoursesPossibleList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LST_CoursePossibleList.SelectedIndexChanged
        'half
        'LST_CourseRequiredItem_Load()
        'CourseRequisitesList_Load()
        'load info about selected course
        Dim SelectedItem = LST_CoursePossibleList.SelectedItem

        For Each row As DataRow In ANS_CoursePossibleList_Load.Rows
            If SelectedItem = row.Item("CourseName") Then
                'LST_CourseRequiredList.Items.Add(row.Item("CourseName"))
                TXT_CoursePossibleName.Text = row.Item("CourseTitle")
                TXT_CoursePossibleTermYear.Text = row.Item("TermYear")
                TXT_CoursePossibleTermPart.Text = row.Item("TermPart")
            End If
        Next row
    End Sub

    Private Sub LST_CoursesCompleteList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LST_CourseCompleteList.SelectedIndexChanged
        'half
        'LST_CourseRequiredItem_Load()
        'CourseRequisitesList_Load()
        'load info about selected course
        Dim SelectedItem = LST_CourseCompleteList.SelectedItem

        For Each row As DataRow In ANS_CourseCompleteList_Load.Rows
            If SelectedItem = row.Item("CourseName") Then
                'LST_CourseRequiredList.Items.Add(row.Item("CourseName"))
                TXT_CourseCompleteName.Text = row.Item("CourseTitle")
                TXT_CourseCompleteTermYear.Text = row.Item("TermYear")
                TXT_CourseCompleteTermPart.Text = row.Item("TermPart")

            End If
        Next row
    End Sub

    Private Sub CourseRequisitesList_Load()
    End Sub
    Private Sub LST_CoursePossibleList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LST_CoursePossibleList.SelectedIndexChanged
        'done
        LST_CoursePossibleItem_Load()
    End Sub
    Private Sub LST_CoursePossibleItem_Load()

    End Sub

    Private Sub LST_CourseCompleteItem_Load()

    End Sub

    Private Sub CoreData_Fill()
        QRY_Student_Find = "SELECT StudentIndex FROM Students WHERE 0 = 0 AND StudentUserName = '{StudentUserName}' AND StudentPassWord = '{StudentPassWord}'"

        ' Student Tab
        QRY_StudentWelcome_Load = "SELECT StudentUserName, StudentPassWord FROM Students WHERE StudentIndex = {StudentIndex}"
        QRY_StudentWelcome_Save = "INSERT INTO Students (StudentUserName, StudentPassWord) VALUES ('{StudentUserName}', '{StudentPassWord}')"

        QRY_StudentAccount_Load = "SELECT StudentUserName, StudentPassWord FROM Students WHERE StudentIndex = {StudentIndex}"
        QRY_StudentAccount_Save = "UPDATE Students SET StudentUserName = '{StudentUserName}' , StudentPassWord = '{StudentPassWord}' WHERE StudentIndex = {StudentIndex}"

        QRY_StudentMajorIndex_Find = "SELECT DegreeIndex FROM StudentsDegree WHERE 0 = 0 AND DegreeType = 0 AND StudentIndex = {StudentIndex}"

        QRY_StudentDegreesList_Load = "SELECT MajorIndex, MajorTitle FROM MajorDefinitions"

        'Course Tab
        QRY_CourseRequiredList_Load = "SELECT CourseIndex, CourseName, CourseTitle FROM Courses WHERE CourseIndex IN ( SELECT CourseIndex FROM EnrollmentStep WHERE 0=0 AND StudentIndex = {StudentIndex} AND TermYear <> '0000' AND TermPart <> '0')"
        QRY_CourseRequiredItem_Load = "SELECT Courses.CourseIndex AS CourseIndex, Courses.CourseTitle AS CourseTitle, EnrollmentStep.TermYear AS TermYear, EnrollmentStep.TermPart AS TermPart FROM EnrollmentStep, Courses WHERE 0 = 0 AND EnrollmentStep.CourseIndex = Courses.CourseIndex AND EnrollmentStep.StudentIndex = {StudentIndex} AND EnrollmentStep.CourseIndex = {CourseIndex}"
        'QRY_CourseRequisitesList_Load = "SELECT CourseName FROM Courses WHERE CourseIndex IN (SELECT CourseDonePast FROM CourseRequisites WHERE 0=0 AND MajorIndex = 0 AND CourseTodoNext = {CourseIndex} )"


        QRY_StudentDegreesItem_Load = "SELECT MajorIndex, MajorTitle FROM MajorDefinitions WHERE MajorIndex IN ( SELECT DegreeIndex FROM StudentsDegree WHERE StudentIndex = {StudentIndex} AND DegreeType = 0 )"
        QRY_StudentDegreesItem_Save = "INSERT INTO StudentsDegree (StudentIndex, DegreeIndex, DegreeType) SELECT {StudentIndex} AS StudentIndex, {DegreeIndex} As DegreeIndex, 0 As DegreeType FROM StudentsDegree WHERE StudentIndex = {StudentIndex} AND DegreeIndex NOT IN({DegreeIndex}) "


        'QRY_CoursePossibleRequisitesList_Load = "SELECT CourseIndex, CourseName FROM Courses WHERE Courseindex IN ( SELECT CourseDonePast AS Courseindex FROM CourseRequisites WHERE CourseTodoNext = {Courseindex})"
        'QRY_CoursePossibleListRequisitedMet_Load = "SELECT CoursesTodoNext.CourseIndex AS CourseIndex, CoursesTodoNext.CourseName AS CourseName, EnrollmentStepDonePast.TermDone, EnrollmentStepTodoNext.TermDone FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext, Courses CoursesTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND EnrollmentStepTodoNext.CourseIndex = CoursesTodoNext.CourseIndex AND EnrollmentStepDonePast.TermDone <> '0000.0' AND EnrollmentStepTodoNext.TermDone = '0000.0' AND EnrollmentStepDonePast.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex}"
        'QRY_CoursePossibleListEarnedGradeTooLow_Load = "SELECT EnrollmentStepTodoNext.CourseIndex FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex} AND EnrollmentStepDonePast.EnrollmentStepIndex = {EnrollmentStepIndex} AND EnrollmentStepDonePast.EnrollmentStepIndex = EnrollmentStepTodoNext.EnrollmentStepIndex AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND CourseRequisites.CourseGradeMinimum > EnrollmentStepDonePast.GradePointsEarned"
        'QRY_CoursePossibleListEarnedHoursTooLow_Load = "SELECT EnrollmentStepTodoNext.CourseI FROM EnrollmentStep EnrollmentStepDonePast, CourseRequisites, EnrollmentStep EnrollmentStepTodoNext WHERE 0 = 0 AND EnrollmentStepDonePast.StudentIndex = {StudentIndex} AND EnrollmentStepTodoNext.StudentIndex = {StudentIndex} AND EnrollmentStepDonePast.CourseIndex = CourseRequisites.CourseDonePast AND EnrollmentStepTodoNext.CourseIndex = CourseRequisites.CourseTodoNext AND CourseRequisites.CourseHoursMinimum > {AccumulatedHours}"

        'QRY_CourseRequired_Load = "SELECT "

        QRY_CoursePossibleList_Load = "SELECT CourseIndex, CourseName, CourseTitle FROM Courses WHERE CourseIndex IN ( SELECT CourseIndex FROM EnrollmentStep WHERE 0=0 AND StudentIndex = {StudentIndex} AND Termpart <> '0000' AND Termpart <> '0')"
        QRY_CoursePossibleItem_Load = "SELECT Courses.CourseIndex AS CourseIndex, Courses.CourseTitle AS CourseTitle, EnrollmentStep.TermYear AS TermYear, EnrollmentStep.TermPart AS TermPart FROM EnrollmentStep, Courses WHERE 0 = 0 AND EnrollmentStep.CourseIndex = Courses.CourseIndex AND EnrollmentStep.StudentIndex = {StudentIndex} AND EnrollmentStep.CourseIndex = {CourseIndex}"
        QRY_CourseCompleteList_Load = "SELECT CourseIndex, CourseName, CourseTitle FROM Courses WHERE CourseIndex IN ( SELECT CourseIndex FROM EnrollmentStep WHERE 0=0 AND StudentIndex = {StudentIndex} AND Termpart <> '0000' AND Termpart <> '0')"
        'QRY_CourseIndex_FindByName = "SELECT CourseIndex FROM Courses WHERE CourseName = {CourseName}"
        QRY_CourseCompleteItem_Load = "SELECT EnrollmentStep.CourseIndex AS CourseIndex, CourseName, CourseTitle, TermYear, TermPart, GradePointsEarned, CreditHoursEarned FROM EnrollmentStep, Courses WHERE 0 = 0 AND StudentIndex = {StudentIndex} AND EnrollmentStep.CourseIndex = Courses.CourseIndex AND EnrollmentStep.CourseIndex = {CourseIndex}"
        QRY_EnrollmentStepAbove_Load = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepDonePast as EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepTodoNext = {EnrollmentStepIndex} )"
        QRY_EnrollmentStepTween_Load = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepIndex = {EnrollmentStepIndex} )"
        QRY_EnrollmentStepBelow_Load = "SELECT EnrollmentStepIndex, EnrollmentStepName FROM EnrollmentStep WHERE EnrollmentStepIndex IN ( SELECT EnrollmentStepTodoNext as EnrollmentStepIndex FROM EnrollmentPath WHERE EnrollmentStepDonePast = {EnrollmentStepIndex} )"
        'QRY_CourseIndex_Find = "SELECT CourseIndex FROM Courses"

        QRY_CourseRequiredList_Find = "SELECT CourseIndex FROM MajorRequirements WHERE  MajorIndex IN ( SELECT DegreeIndex AS MajorIndex FROM StudentsDegree WHERE 0=0 AND DegreeType = 0 AND StudentIndex = {StudentIndex} )"

        QRY_CourseRequiredList_Load = "SELECT Courses.CourseIndex, Courses.CourseName, Courses.CourseTitle, EnrollmentStep.TermYear, EnrollmentStep.TermPart, EnrollmentStep.GradeEarned, EnrollmentStep.HoursEarned FROM EnrollmentStep, Courses WHERE EnrollmentStep.CourseIndex = Courses.CourseIndex AND Courses.CourseIndex IN ({LST_CourseRequiredList_Find})"

        'edit these
        QRY_CoursePossibleList_Find = "SELECT CourseIndex FROM MajorRequirements WHERE  MajorIndex IN ( SELECT DegreeIndex AS MajorIndex FROM StudentsDegree WHERE 0=0 AND DegreeType = 0 AND StudentIndex = {StudentIndex} )"
        'edit these
        QRY_CoursePossibleList_Load = "SELECT Courses.CourseIndex, Courses.CourseName, Courses.CourseTitle, EnrollmentStep.TermYear, EnrollmentStep.TermPart, EnrollmentStep.GradeEarned, EnrollmentStep.HoursEarned FROM EnrollmentStep, Courses WHERE EnrollmentStep.CourseIndex = Courses.CourseIndex AND Courses.CourseIndex IN ({LST_CoursePossibleList_Find})"

        'edit these
        QRY_CourseCompleteList_Find = "SELECT CourseIndex FROM MajorRequirements WHERE  MajorIndex IN ( SELECT DegreeIndex AS MajorIndex FROM StudentsDegree WHERE 0=0 AND DegreeType = 0 AND StudentIndex = {StudentIndex} )"
        'edit these
        QRY_CourseCompleteList_Load = "SELECT Courses.CourseIndex, Courses.CourseName, Courses.CourseTitle, EnrollmentStep.TermYear, EnrollmentStep.TermPart, EnrollmentStep.GradeEarned, EnrollmentStep.HoursEarned FROM EnrollmentStep, Courses WHERE EnrollmentStep.CourseIndex = Courses.CourseIndex AND Courses.CourseIndex IN ({LST_CourseCompleteList_Find})"

        'QRY_CoursesCompleteList_Find = ""
        'QRY_CourseInfo_Load()


    End Sub
    Private Sub CourseRequiredList_Find()
        'Dim StudentIndex As Integer = 48

        Dim QRY As String = QRY_CourseRequiredList_Find

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_CourseRequiredList_Find = Data_Load(QRY, dtacon)

        LST_CourseRequiredList_Find = ""

        For Each row As DataRow In ANS_CourseRequiredList_Find.Rows
            If LST_CourseRequiredList_Find.Length > 0 Then
                LST_CourseRequiredList_Find &= ", "
            End If
            LST_CourseRequiredList_Find &= (row.Item("CourseIndex"))

            '
            TextBox1.Text = LST_CourseRequiredList_Find
            '
        Next row
    End Sub

    Private Sub CourseCompleteList_Find()
        'Dim StudentIndex As Integer = 48

        Dim QRY As String = QRY_CourseCompleteList_Find

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_CourseCompleteList_Find = Data_Load(QRY, dtacon)

        LST_CourseCompleteList_Find = ""

        For Each row As DataRow In ANS_CourseCompleteList_Find.Rows
            If LST_CourseCompleteList_Find.Length > 0 Then
                LST_CourseCompleteList_Find &= ", "
            End If
            LST_CourseCompleteList_Find &= (row.Item("CourseIndex"))

            '
            TextBox1.Text = LST_CourseCompleteList_Find
            '
        Next row
    End Sub

    Private Sub CoursePossibleList_Find()
        Dim QRY As String = QRY_CoursePossibleList_Find

        QRY = QRY.Replace("{StudentIndex}", StudentIndex)

        ANS_CoursePossibleList_Find = Data_Load(QRY, dtacon)

        LST_CoursePossibleList_Find = ""

        For Each row As DataRow In ANS_CoursePossibleList_Find.Rows
            If LST_CoursePossibleList_Find.Length > 0 Then
                LST_CoursePossibleList_Find &= ", "
            End If
            LST_CoursePossibleList_Find &= (row.Item("CourseIndex"))
        Next row
    End Sub


End Class
